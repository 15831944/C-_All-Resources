#include <stdio.h>

int main()
{
    int s,m,i,n,a,b;
    scanf("%d %d",&s,&m);
    i=s/100;
    a=s%100;
    n=i*60+a+m;
    b=n/60*100+n-n/60*60;
    printf("%d\n",b);
    return 0;
}
