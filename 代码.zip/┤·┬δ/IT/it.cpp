# include <stdio.h>
int main()
{
	int i;
	int n;
	int m;
	scanf("%d",&n);
	for(i=1;i<=n;i++){
		for(m=n;m>=i;m--){
			printf(" ");
		} 
		for(m=n-i;m<n;m++){
			printf("*");
		}
			printf("\n");
	}
}
