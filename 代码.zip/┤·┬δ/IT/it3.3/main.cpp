#include <stdio.h>
#include<math.h>
int main()
{
   double n,m;
    scanf("%lf",&n);
    m=fabs(n);
    printf("%.2f\n",m);
    return 0;
}
