#include <stdio.h>
int main()
{
    int s,d,h,m;
    scanf("%d",&s);
    d=s/(24*60*60);
    h=(s-24*60*60*d)/(60*60);
    m=(s-24*60*60*d-60*60*h)/60;
    s=s-24*60*60*d-60*60*h-60*m;
    printf("%d %d %d %d\n",d,h,m,s);
    return 0;
}
