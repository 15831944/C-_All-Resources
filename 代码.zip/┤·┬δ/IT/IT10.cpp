# include <stdio.h>
int main()
{
	int S;
	int W;
	int F;
	int P;
	double D;
	scanf("%d",&S);
	P=100;
	W=20;
	if(S<250){
		D==0;
	}
	if(S>=250&&S<500){
		D==0.02;
	}
	if (S>=500&&S<1000){
		D==0.05;
	}
	if(S>=1000&&S<2000){
		D==0.08;
	}
	if(S>=2000&&S<3000){
		D==0.1;
	}
	if(S>=3000){
		D==0.15;
	}
	F=P*W*S*(1-D);
	printf("%d",F);
}
