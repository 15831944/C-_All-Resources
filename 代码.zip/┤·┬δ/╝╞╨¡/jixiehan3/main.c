#include <stdio.h>
#include <stdlib.h>

int main()
{
    FILE *fp;
    int c1=-1,c,sum=0,n=0;
    double a,s;
    char name[10000];
    fp=fopen("score.txt","r");
    if(fp!=NULL)
    {
        while(fscanf(fp,"%d %s %lf",&c,&name,&s)!=EOF)
        {
            if(c1==-1||c1==c)
            {
                sum+=s;
                n++;
                c1=c;
            }
            else
            {
                a=sum*1.0/n;
                printf("%d %f\n",c,a);
                c1=-1;
                sum=s;
            }
        }
    }
    a=sum*1.0/n;
    printf("%d %f",c,a);
    return 0;
}
