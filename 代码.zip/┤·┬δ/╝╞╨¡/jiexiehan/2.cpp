#include <stdio.h>
#include <stdlib.h>
#include <string.h>
int main()
{
	 char buf[1000];  
	 FILE *fp;            
	 int len,line=1;             
	 if((fp = fopen("test.txt","r")) == NULL)
	 {
		  printf("Can not open this file\n");
	 }
	 while(fgets(buf,1000,fp) != NULL)
	 {
		 len = strlen(buf);
		 buf[len-1] = '\0';  
		 printf("<%d> %s\n",line,buf);
		 line++;
	 }
	return 0;
}
