#include <stdio.h>
#include <stdlib.h>
int main()
{
	FILE *fp;
	int num,score=0,num1,score1=0,flag=0,i=0;
	char name[20];
	fp=fopen("score.txt","r");
	if(fp==NULL)
	{
		printf("error open file!\n");
	}
	else
	{
		while(fscanf(fp,"%d %s %d",&num,&name,&score)!=EOF)
		{
			if(flag==0)
			{
				num1=num;
			}
			flag=1;
			if(num1==num)
			{
				score1+=score;
				i++;
			}
			else
			{
				num1=num;
				printf("%d %d\n",num1,score1/i);
				i=1;
				score1=0;
			} 
		}
		printf("%d %d\n",num1,score1/i);
		fclose(fp);
	}
	return 0;
}
