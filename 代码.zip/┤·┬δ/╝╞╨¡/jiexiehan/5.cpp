#include<stdio.h>
#include<stdlib.h>
#include<string.h>

struct node
{
	char num[10], score[10];
	struct node*link;
};

typedef node NODE;

int main()
{
	NODE *head;
	NODE *p;
	p=(NODE *)malloc(sizeof(NODE));
	p->link=NULL;
	head=p;
	int create (NODE *head,int n);
	create(head,2);
	int output (NODE *head);
	output(head);
	int n,i;
	char num[10],score[10];
	printf("Please input the num:");
	scanf("%d",&n);
	while(i<n)
	{
	if(p->num == n)
	{
	printf("%d,%.2f\n",p->num,p->score);
	p=p->link;
    }
    i++;
    }
	return 0;
}

int create (NODE *head,int n)
{
	NODE *p;
	for(;n>0;n--)
	{
		p=(NODE*)malloc(sizeof(NODE));
		scanf("%c%c",&p->num,&p->score);
		p->link=head->link;
		head->link=p;
	}
	return 0;
}

int output (NODE *head)
{
	NODE *p;
	p=head->link;
	while(p!=NULL)
	{
		printf("%c,%c\n",p->num,p->score);
		p=p->link;
	}
	return 0;
}
