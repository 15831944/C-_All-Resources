#include <stdio.h>
#include <stdlib.h>

int main()
{
    int i,j;
    FILE *fpt;
    char a[10000],b[10000];
    for(i=0;; i++)
    {
        scanf("%c",&a[i]);
        if(a[i]=='!')
        {
            break;
        }
        b[i]=a[i];
    }
    for(j=0; j<=i; j++)
    {
        if(b[j]>='a'&&b[j]<='z')
        {
            b[j]=b[j]-32;
        }
    }
    fpt = fopen("test.txt","w");
    fprintf(fpt,"%s",b);
    fclose(fpt);
    return 0;
}
