#include<stdio.h>
# define maxn 105

struct student
{
	int num;
	int score;
 } stu[maxn];
 
 void sort(struct student stu[],int n)
 {
 	int i,j;
 	struct student t;
 	for(i=0;i<n-1;i++)
 	{
 		for(j=0;j<n-1;j++)
 		{
 			if(stu[j].score>stu[j+1].score||(stu[j].score==stu[j+1].score&&stu[j].num>stu[j+1].num))
 			{
 				t=stu[j];
 				stu[j]=stu[j+1];
 				stu[j+1]=t;
			 }
		 }
	 }
 }
 
 int main()
 {
 	int i,N;
 	while(scanf("%d",&N)!=EOF)
 	{
 		for(i=0;i<N;i++)
 		scanf("%d%d",&stu[i].num,&stu[i].score);
 		sort(stu,N);
 		for(i=0;i<N;i++)
 		printf("%d %d\n",stu[i].num,stu[i].score);
	 }
 	
 	return 0;
 }
