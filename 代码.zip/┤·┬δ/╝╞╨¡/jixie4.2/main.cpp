#include <stdio.h>

int main()
{
    int i,n;
    for(i=1;i<=9;i++)
    {
     for(n=1;n<=i;n++)
     {
       printf("%d*%d=%d\t",i,n,i*n);
     }
     printf("\n");
    }
    return 0;
}
