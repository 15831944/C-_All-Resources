#include<stdio.h>
#include<stdlib.h>
#include <time.h>
int main()
{
    int x,num,i;
    srand((unsigned)time(NULL));
    x=rand()%100;
    i=0;
    while(scanf("%d",&num)!=EOF)
    {
        if(num>x)
        {
            printf("%d����\n",num);
            i++;
        }
        if(num<x)
        {
            printf("%dС��\n",num);
            i++;
        }

        if(num==x)
        {
            printf("��ȷ\n");
            return 0;
        }
        if(i==5)
        {
            return 0;
        }
    }
    return 0;
}
