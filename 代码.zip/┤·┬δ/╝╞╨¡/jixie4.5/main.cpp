#include <stdio.h>
#include <string.h>
int main()
{
    int i,n,len;
    char a[100],b[100];
    n=0;
    gets(a);
    len=strlen(a);
    for(i=0;i<len;i++)
    {
        b[i]=a[len-1-i];
    }
    for(i=0;i<len;i++)
    {
        if(a[i]==b[i])
        {
            n++;
        }
    }
    if(n==len)
    {
        printf("Yes");
    }
    else
    {
        printf("No");
    }
    return 0;
}
