#include <stdio.h>
#include <stdlib.h>
#include <string.h>
int main()
{
    FILE *fp;
    int len,line=1;
    char b[10000];
    fp=fopen("C:\\Users\\����\\Desktop\\����\\��Э\\jiexiehan\\test.txt","rb");
    if(fp!=NULL)
    {
            while(1)
      {
        fgets(b,10000,fp);
        len=strlen(b);
        if(len==0)
        {
            break;
        }
        if((b[len-1]=='\n')&&(b[len-2]=='r'))
        {
            b[len-1]=0;
            b[len-2]='\n';
        }
        printf("<%d> %s",line,b);
        line++;
      }
    }
    fclose(fp);
    return 0;
}
