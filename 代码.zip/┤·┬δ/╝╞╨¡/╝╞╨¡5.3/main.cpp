#include <stdio.h>

int main()
{
    int i,j,n=0,m=2,num=2;
    printf("1 2 ");
    for(i=3;i<=100;i++)
    {    n=0;
        for(j=2;j<i;j++)
        {
            if(i%j!=0)
            {
                n++;
            }
        }
        if(n==i-2)
        {
            printf("%d ",i);
            m+=1;
            num++;
        }
        else if(num==10)
        {
            printf("\n");
            num=0;
        }
    }
    printf("\n");
    printf("%d",m);
    return 0;
}
