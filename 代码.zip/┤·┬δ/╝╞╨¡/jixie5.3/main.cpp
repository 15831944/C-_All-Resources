#include <stdio.h>
void function(int num1,int num2)
{
    int a[2],b=1,t,mul,i;
    mul=num1*num2;
    if(num1<num2)
    {
        t=num1;
        num1=num2;
        num2=t;
    }
    while(num2!=0)
    {
    b=num1%num2;
    num1=num2;
    num2=b;
    }
    a[0]=num1;
    a[1]=mul/a[0];
     for(i=0;i<=1;i++)
    {
        printf("%d ",a[i]);
    }
}
int main()
{
    int num1,num2;
    scanf("%d %d",&num1,&num2);
    function(num1,num2);
    return 0;
}
