#include <stdio.h>
int main()
{
  int a,n,i,c;
  scanf("%d",&n);
  c=n;
  for(i=1;i<=4;i++)
  {
      a=c%b;
      c=c/b;
    printf("%d",a);
  }

    return 0;
}
