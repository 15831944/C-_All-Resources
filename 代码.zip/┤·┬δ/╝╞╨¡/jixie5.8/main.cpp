#include <stdio.h>

int main()
{
    int i,n=0;
    char a[10]={'a','b','c','d','e','f','g'},b;
    scanf("%c",&b);
    for(i=0;i<7;i++)
    {
        if(a[i]==b)
        {
            printf("%d",i);
        }
        else if(a[i]!=b)
        {
           n++;
        }
    }
    if(n==7)
     printf("No");
    return 0;
}
