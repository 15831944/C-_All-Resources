#include <stdio.h>
int main()
{
   char a[6]= {1, 5, 3, 7, 2, 8};
   int i,m,t;
   for(i=0;i<5;i++)
   {
       for(m=0;m<5-i;m++)
       {
           if(a[m]>a[m+1])
           {
               t=a[m];
               a[m]=a[m+1];
               a[m+1]=t;
           }
       }
   }
   for(i=0;i<6;i++)
   {
       printf("%d",a[i]);
   }
    return 0;
}
