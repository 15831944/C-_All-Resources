#include <stdio.h>
#include <stdlib.h>

int main()
{
    FILE *fp;
    if(fp!=NULL)
    {
        int i,n=1;
        char a[10000];
        for(i=0;;i++)
        {
            fp=fopen("test.txt","w");
            scanf("%c",&a[i]);
            if(i==0)
            {
                fprintf(fp,"<%d>",n);
                n++;
            }
            if(scanf("%c",&a[i])=='\n')
            {
                fprintf(fp,"<%d>",n);
                n++;
            }
            if(scanf("%c",&a[i])=='!')
            {
                return 0;
            }
            else
            {
                fprintf(fp,"%c",a[i]);
            }

        }
    }
    return 0;
}
