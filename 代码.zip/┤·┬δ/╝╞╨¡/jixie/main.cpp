#include <stdio.h>

int main()
{
    int x,y,z,t[10],n,i,j;
    scanf("%d %d %d",&x,&y,&z);
    t[1]=x;
    t[2]=y;
    t[3]=z;
    for(i=1;i<=3;i++)
    {
        for(j=1;j<=3-i;j++)
        {
            if(t[j]>t[j+1])
            {
                n=t[j];
                t[j]=t[j+1];
                t[j+1]=n;
            }
        }
    }
    printf("%d %d %d",t[1],t[2],t[3]);
    return 0;
}
