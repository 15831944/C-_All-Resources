#include <stdio.h>
int main()
{
    int i;
    for(i=1;i<=10;i++)
    {
    printf("HELLO world\n");
    }
    return 0;
}
