#include <stdio.h>
void function()
{
    int i;
    for(i=1;i<=10;i++)
    {
        printf("hello world\n");
    }
}
int main()
{
    function();
    return 0;
}


