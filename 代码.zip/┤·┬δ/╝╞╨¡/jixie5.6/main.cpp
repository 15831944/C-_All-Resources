#include <stdio.h>

int main()
{
    int i,n,j,a[100][100],num1,m;
    scanf("%d",&n);
    a[1][1]=1;
    for(i=2;i<=n;i++)
    {
        for(j=1;j<=i;j++)
        {
            a[i][j]=a[i-1][j]+a[i-1][j-1];
        }
    }
    for(i=1;i<=n;i++)
    {
        num1=n-i;
        for(m=1;m<=num1;m++)
            {
                printf(" ");
            }
        for(j=1;j<=i;j++)
        {
            printf("%d ",a[i][j]);
        }
      for(m=1;m<=num1;m++)
            {
                printf(" ");
            }
        printf("\n");
    }
    return 0;
}
