#include <stdio.h>
void function(int a)
{
    int i,sum=0,mul=1;
    for(i=1;i<=a;i++)
    {
        sum+=i;
        mul*=i;
    }
    printf("%d %d\n",sum,mul);
}

int main()
{
    int a,b,c;
    scanf("%d %d %d",&a,&b,&c);
    function(a);
    function(b);
    function(c);
    return 0;
}
