#include <stdio.h>
#include <string.h>
int main()
{
    int i,n=0,len,j;
    char a[10]={'a','b','c','d','e','f','g'},b[10];
    gets(b);
    len=strlen(b);
    for(i=0;i<7;i++)
    {
        if(a[i]==b[0])
        {
            for(j=1;j<len;j++)
            {
                if(a[i+j]==b[j])
                {
                    n++;
                }
            }
        }
    }
    if(n==len-1)
        printf("Yes");
    else
        printf("No");
    return 0;
}
