#include <stdio.h>

int main()
{
    int t,n[10000],k[10000],i,a[10000];
    scanf("%d",&t);
    for(i=0;i<t;i++)
    {
        scanf("%d %d",&n[i],&k[i]);
        a[i]=i+1;
    }
    for(i=0;i<t;i++)
    {
        m+=k-1;
    }

    return 0;
}
