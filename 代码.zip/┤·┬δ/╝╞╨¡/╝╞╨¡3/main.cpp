#include <stdio.h>
#include<math.h>
int main()
{
    double n,i;
    scanf("%lf",&n);
    i=fabs(n);
    printf("%.2f\n",i);
    return 0;
}
