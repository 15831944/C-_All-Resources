    #include <stdio.h>

    int main()
    {
        int n,i,a,b,m,pai;
        scanf("%d",&n);
         pai=n;
         m=n;
     for(i=1;i<=n;i++)
     {
         for(a=1;a<i;a++)
             {
                 printf(" ");
             }
         for(b=1;b<=2*pai-1;b++)
         {
             printf("%d",m);
         }
          for(a=1;a<i;a++)
             {
                 printf(" ");
             }
         m--;
          pai--;
         printf("\n");
     }
         pai=1;
         m=n;
     for(i=1;i<=n;i++)
     {
         for(a=1;a<m;a++)
             {
                 printf(" ");
             }
         for(b=1;b<=2*pai-1;b++)
         {
             printf("%d",i);
         }
          for(a=1;a<m;a++)
             {
                 printf(" ");
             }
         m--;
          pai++;
         printf("\n");
     }

        return 0;
        }

