#include <stdio.h>

int main()
{
    int a[10],i,max,min,m,n,t;
    for(i=0;i<10;i++)
    {
        scanf("%d",&a[i]);
    }
    max=a[0];
    min=a[0];
    for(i=0;i<10;i++)
    {
        if(max<a[i])
        {
            max=a[i];
            m=i;
        }
        else if(min>a[i])
        {
            min=a[i];
            n=i;
        }
    }
    t=a[0];
    a[0]=min;
    a[n]=t;
    t=a[9];
    a[9]=max;
    a[m]=t;
    printf("%d",a[0]);
    for(i=1;i<10;i++)
    {
        printf(" %d",a[i]);
    }
    return 0;

}
