#include <stdio.h>
#include <stdlib.h>

int main()
{
    int n,i,j,num=0,count=0,a[10],sum=0;
    printf("Input n(n<=500):");
    scanf("%d",&n);
    for(i=n;count<10;i--)
    {
        num=0;
        for(j=2;j<i;j++)
        {
            if(i%j!=0)
            {
                num++;
            }
        }
        if(num==i-2)
        {
            a[count]=i;
            count++;
        }
        if(i<0)
        {
            break;
        }
    }
    for(i=0;i<count;i++)
    {
        printf("%6d",a[i]);
        sum+=a[i];
    }
    printf("\nsum=%d\n",sum);
    return 0;
}
