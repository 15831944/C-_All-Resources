#include<stdio.h>
#include<stdlib.h>
#include<string.h>
int f(int n)
{
    int i,num=1;
    if(n==0)
    {
        return 1;
    }
    else
    {
        for(i=1;i<=n;i++)
        {
            num*=i;
        }
        return num;
    }
}
int main()
{
    int a,b,c;
    long m=0;
    for(a=1;a<10;a++)
    {
        for(b=0;b<10;b++)
        {
            for(c=0;c<10;c++)
            {
                m=a*100+b*10+c;
                if(m==(f(a)+f(b)+f(c)))
                {
                    printf("%ld\n",m);
                }
            }
        }
    }
    return 0;
}
