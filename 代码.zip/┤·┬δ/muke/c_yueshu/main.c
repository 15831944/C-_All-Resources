#include <stdio.h>
#include <stdlib.h>
int Func(int n)
{
    int i;
    for(i=999;i>=100;i--)
    {
        if(n%i==0)
        {
            return i;
        }
    }
    return 0;
}
int main()
{
    int n,num;
    printf("Input n:");
    scanf("%d",&n);
    if(n<1000||n>1000000)
    {
        printf("Input error!\n");
        return 0;
    }
    num=Func(n);
    printf("%d\n",num);
    return 0;
}
