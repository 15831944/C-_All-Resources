#include <stdio.h>
#include <stdlib.h>

int main()
{
   int i,j,s[2][5]={{86,74,92,77,82},{81,87,90,62,88}};
   float avr,sum=0.0,sum1=0;
   for(i=0;i<2;i++)
   {
       sum1=0;
       for(j=0;j<5;j++)
       {
            sum1+=s[i][j];
       }
       if(i==0)
       {
           sum1=sum1*0.3;
       }
       else
       {
           sum1=sum1*0.7;
       }
       sum+=sum1;
   }
   avr=sum*1.0/5;
   printf("total=%.2f\n",sum);
   printf("average=%.2f\naverage=%d\n",avr,(int)avr);
    return 0;
}
