#include <stdio.h>
#include <stdlib.h>
int IsPrime(int x)
{
    int i;
    if(x==2)
    {
        return x;
    }
    for(i=2; i<x; i++)
    {
        if(x%i==0)
        {
            return 0;
        }
    }
    return x;
}
int main()
{
    int n,sum=0,num,i;
    printf("Input n:");
    scanf("%d",&n);
    for(i=2;i<=n;i++)
    {
        num=IsPrime(i);
        sum+=num;
    }
    printf("sum=%d\n",sum);
    return 0;
}
