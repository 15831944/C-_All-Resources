#include <stdio.h>
#include <stdlib.h>

/*int main()
{
    int y;
    scanf("%d",&y);
    if(y<1)
    {
        printf("Input error!\n");
    }
    else
    {
        if((y%4==0&&y%100!=0)||y%400==0)
        {
            printf("Yes\n");
        }
        else
        {
            printf("No\n");
        }
    }
    return 0;
}*/
 #include<stdio.h>
   int main()
   {
       int score;
       char grade;
       printf("Please input score:\n");
       scanf("%d", &score);
       if (score < 0 || score > 100)
       {
            printf("Input error!\n");
       }
        else
        {
        if (score >= 90)
             grade = 'A';
        else if (score >= 80)
             grade = 'B';
        else if (score >= 70)
             grade = 'C';
        else if (score >= 60)
             grade = 'D';
        else
             grade = 'E';
        printf("grade: %c\n", grade);
        }
        return 0;
}
