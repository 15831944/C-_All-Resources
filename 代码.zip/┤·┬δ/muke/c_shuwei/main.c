#include <stdio.h>
#include <stdlib.h>

int main()
{
    int n=4321,a,b;
    a=n/100;
    b=n%100;
    printf("a=%d,b=%d\na+b=%d\na-b=%d\na*b=%d\na/b=%.2f\na%%b=%d\n",a,b,a+b,a-b,a*b,a*1.0/b,a%b);
    return 0;
}
