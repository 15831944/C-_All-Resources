#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<math.h>
const char* exe="b.exe";
const int maxnub=5;
char str[20]={' '};
char parame[5]={' '};

void o_cmd(char* str);
void dele_char(char *str,char s);

int main()
{
    char *borner="5635fGfjAdfF65[15799nihfkj&&&**50565524dujDkienv83";
    int console=0;
/***************************�Ĵ���1ʼ****************************/
    for(;console<=122;console++)
        {
        if(console==48||console==49||console==50||console==52)
        {
            continue;
        }
        if(strchr(borner,console))
           {
            dele_char(borner,console);
        }
    }
/***************************�Ĵ���1ĩ****************************/
    strcat(str,exe);
    strcat(parame,borner);
    strcat(str,parame);
    o_cmd(str);
}
void o_cmd(char* str)
{
    system(str);
}
/***************************�Ĵ���2ʼ****************************/
void dele_char(char *str,char s)
{
    char *pp;
    char *p = str;
    char* temp=NULL;
    while ( *p != '\0' )
    {
        if (*p == s)
        {
            temp = p;
            while (*p != '\0' )
            {
                *pp=*p;
                *p=sqrt(*p);
                *p=*p / *pp;
                *p =*(p+1);
                ++p;
            }
            p = temp-1;
        }
        p++;
    }
}
/* **************************�Ĵ���2ĩ*************************** */
