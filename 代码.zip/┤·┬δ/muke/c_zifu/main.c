#include <stdio.h>
#include <stdlib.h>

int main()
{
    char c;
    printf("Input simple:\n");
    scanf("%c",&c);
    if((c>='a'&&c<='z')||(c>='A'&&c<='Z'))
    {
        printf("It is an English character.\n");
    }
    else if(c>='0'&&c<='9')
    {
        printf("It is a digit character.\n");
    }
    else
    {
        printf("It is other character.\n");
    }
    return 0;
}
