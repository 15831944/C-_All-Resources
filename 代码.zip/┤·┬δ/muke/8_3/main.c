#include <stdio.h>
#include <stdlib.h>

int main()
{
    int i,j,count=0,b,c,i1,i2,i3,b1,b2,b3,c1,c2,c3,n[10]={0};
    for(i=123;i<333;i++)
    {
        count=0;
            b=2*i;
            c=3*i;
            i1=i/100;
            n[i1]++;
            i2=i%100/10;
            n[i2]++;
            i3=i%100%10;
            n[i3]++;
            b1=b/100;
            n[b1]++;
            b2=b%100/10;
            n[b2]++;
            b3=b%100%10;
            n[b3]++;
            c1=c/100;
            n[c1]++;
            c2=c%100/10;
            n[c2]++;
            c3=c%100%10;
            n[c3]++;

            for(j=0;j<10;j++)
            {
                if((n[j]!=1&&j!=0)||n[0]!=0)
                {
                    break;
                }
                count++;
            }
            if(count==10)
            {
                printf("%d,%d,%d\n",i,2*i,3*i);
            }
            for(j=0;j<10;j++)
            {
                n[j]=0;
            }
    }
    return 0;
}

