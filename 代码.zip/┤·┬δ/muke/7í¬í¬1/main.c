#include <stdio.h>
#include <stdlib.h>
#include <math.h>
double func(double x,int n)
{
    if(n==0)
    {
        return 0;
    }
    else
    {
        return sqrt(x+func(x,n-1));
    }
}
int main()
{
    int n;
    double x,r;
    printf("Please input x and n:");
    scanf("%lf,%d",&x,&n);
    r=func(x,n);
    printf("Result=%.2f\n",r);
    return 0;
}
