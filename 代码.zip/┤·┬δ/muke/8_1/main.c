#include <stdio.h>
#include <stdlib.h>
int geta(int a[],int h,int n)
{
    int i,count=0;
    for(i=0;i<n;i++)
    {
        if(a[i]<=(h+30))
        {
            count++;
        }
    }
    return count;
}
int main()
{
    int a[10],h,i,r;
    for(i=0;i<10;i++)
    {
        scanf("%d",&a[i]);
    }
    scanf("%d",&h);
    r=geta(a,h,10);
    printf("%d",r);
    return 0;
}
