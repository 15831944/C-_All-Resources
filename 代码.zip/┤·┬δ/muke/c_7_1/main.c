#include <stdio.h>
#include <stdlib.h>
#include <math.h>
double Y (double x,int n)
{
    double r=0;
    if(n!=0)
    {
        r+=sqrt(x,0.5);
        Y(r,n-1);
    }
    else
    {
        return r;
    }
    return 0;
}
int main()
{
    int n;
    double x,r;
    printf("Please input x and n:");
    scanf("%lf,%d",&x,&n);
    r=Y(x,n);
    printf("Result=%.2f\n",r);
    return 0;
}
