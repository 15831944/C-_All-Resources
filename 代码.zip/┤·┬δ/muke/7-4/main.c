#include <stdio.h>
#include <stdlib.h>

int main()
{
    float p,c;
    printf("Input payment:");
    scanf("%f",&p);
    switch((int)p/100)
    {
    case 0 :
        c=0;
        break;
    case 1:
       c=0.05;
        break;
    case 2:
    case 3:
    case 4:
        c=0.08;
        break;
    case 5:
    case 6:
    case 7:
    case 8:
    case 9:
        c=0.1;
        break;
    default:
        c=0.15;
    }
    printf("price = %.1f\n",p*(1-c));
    return 0;
}
