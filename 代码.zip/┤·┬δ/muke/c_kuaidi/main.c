#include <stdio.h>
#include <stdlib.h>

int main()
{
    int q,a=0;
    float w,sum=0;
    scanf("%d,%f",&q,&w);
    if(q<0||q>5)
    {
        printf("Error in Area\n");
    }
    else
    {

        if(w>1)
        {
            a=(w-1)/1;
            if(w-a-1>0)
            {
                a++;
            }
        }
        if(q==0)
        {

            sum=10+3*a;
        }
        else if(q==1)
        {
            sum=10+4*a;
        }
        else if(q==2)
        {
            sum=15+a*5;
        }
        else if(q==3)
        {
            sum=15+6.5*a;
        }
        else if(q==4)
        {
            sum=15+10*a;
        }

    }
    printf("Price: %5.2f\n",sum);
    return 0;
}
