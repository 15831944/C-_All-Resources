#include <stdio.h>
#include <stdlib.h>
#include <string.h>
struct link *creat(struct link *head);
struct link
{
    int num;
    char name[20];
    int score;
    struct link *next;
};
struct link *creat(struct link *head)
{
    struct link *pr=head,*p=NULL;
    int nu,s;
    char na[20];
    p=(struct link*)malloc(sizeof(struct link));

    if(head==NULL)
    {
        head=p;
    }
    else
    {
        while(pr->next!=NULL)
        {
            pr=pr->next;
        }
        pr->next=p;
    }
    scanf("%d %s %d",&nu,na,&s);
    strcpy(p->name,na);
    p->num=nu;
    p->score=s;
    p->next=NULL;
    return head;
}
void check(int n,struct link *head)
{
    struct link *pr=head,*p=head;
    int flag=0,flag1=0;
    while(1)
    {
        if(pr->num==n)
        {
            printf("%s %d",pr->name,pr->score);
            flag=1;
            p->next=pr->next;
            free(pr);

        }
        if(pr->next==NULL)
        {
            break;
        }
        else
        {
            if(flag1==0)
            {
                flag1=1;
            }
            pr=pr->next;
            if(flag1==1)
            {
                p=p->next;
            }
        }
    }
    if(flag==0)
    {
        printf("Error");
    }
}
int main()
{
    struct link *head=NULL;
    int i,n,num;
    scanf("%d",&n);
    for(i=0;i<n;i++)
    {
        head=creat(head);
    }
    scanf("%d",&num);
    check(num,head);
    return 0;
}
