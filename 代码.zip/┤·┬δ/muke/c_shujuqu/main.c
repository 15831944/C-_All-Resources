#include <stdio.h>
#include <stdlib.h>

int main()
{
    int n;
    printf("Please enter the number:\n");
    scanf("%d",&n);
    if(n<=0||n>=10000)
    {
        printf("error!\n");
    }
    else
    {
        if(n/10<1)
        {
            printf("%d: 0-9\n",n);
        }
        else if(n/100<1)
        {
            printf("%d: 10-99\n",n);
        }
        else if(n/1000<1)
        {
            printf("%d: 100-999\n",n);
        }
        else if(n/10000<1)
        {
            printf("%d: 1000-9999\n",n);
        }
    }

    return 0;
}
