#include <stdio.h>
#include <stdlib.h>
#include <math.h>
int main()
{
    int n;
    double rate,c,d;
    printf("Please enter rate, year, capital:\n");
    scanf("%lf,%d,%lf",&rate,&n,&c);
    d=c*pow((1+rate),n);
    printf("deposit=%.3f\n",d);
    return 0;
}
