#include <stdio.h>
#include <stdlib.h>

int main()
{
    int a=-11,b=5;
    printf("negative: %d\npositive: %d\n",a%b,b+a%5);
    return 0;
}
