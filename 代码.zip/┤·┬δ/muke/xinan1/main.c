#include <stdio.h>
#include <stdlib.h>

int main()
{
    int i,j,n=0,num[10000]={0},sum=0;
    for(i=1;i<=10000;i++)
    {
        for(j=1;j<=i;j++)
        {
            if(i%j==0)
            {
                num[n]=j;
                n++;
            }
        }
        for(j=0;j<n;j++)
        {
            if(num[j]!=0)
            {
               sum+=num[j];
            }
            num[j]=0;

        }
        if(i==sum)
        {
            printf("%d ",i);
        }
        sum=0;
    }
    return 0;
}
