#include <stdio.h>
#include <stdlib.h>

int main()
{
    int i,j,k;
    printf("Man   Women   Children\n");
    for(i=1;i<=30;i++)
    {
        for(j=1;j<=30;j++)
        {
            k=30-i-j;
            if(3*i+2*j+k==50&&k>0)
            {
               printf("%3d%8d%8d\n",i,j,k);
            }
        }
    }

    return 0;
}
