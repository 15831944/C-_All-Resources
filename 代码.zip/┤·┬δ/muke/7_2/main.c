#include <stdio.h>
#include <stdlib.h>
int sum(int n)
{
    if(n==1)
    {
        return 1;
    }
    else
    {
        return n+sum(n-1);
    }
}
int main()
{
    int n,r;
    printf("Please input n:");
    scanf("%d",&n);
    if(n<1)
    {
        printf("data error!\n");
        return 0;
    }
    else
    {
       r=sum(n);
       printf("sum=%d\n",r);
    }

    return 0;
}
