#include <stdio.h>
#include <stdlib.h>
void select(int n[],int low,int high)
{
    int a=num[low],t;
    while(low<high)
    {
        while(a<n[high-1])
        {
            high--;
        }
        while(a>n[low+1])
        {
            low++;
        }
        t=n[high];
        n[high]=n[low];
        n[low]=t;
    }
    t=n[low];
    n[low]=a;
    n[low]=t;
    select(n,0,low);
    select(n,low,9);
}
int main()
{
    int num[]={2,3,1,6,4,9,8,7,5,0};
    select(num,0,9);
    return 0;
}
