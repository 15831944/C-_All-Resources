#include <stdio.h>
#include <stdlib.h>
#include <math.h>
int main()
{
    float a,b,c,x1,x2;
    printf("Please enter the coefficients a,b,c:\n");
    scanf("%f,%f,%f",&a,&b,&c);
    if((b*b-4*a*c)<0)
    {
        printf("error!\n");
    }
    else
    {
        x1=((-b-sqrt(b*b-4*a*c)))/(2*a);
        x2=((-b+sqrt(b*b-4*a*c)))/(2*a);
        printf("x1=%7.4f, x2=%7.4f\n",x2,x1);
    }
    return 0;
}

