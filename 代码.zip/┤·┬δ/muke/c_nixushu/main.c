#include <stdio.h>
#include <stdlib.h>
#include <math.h>
int main()
{
    int n,g,s,b;
    printf("Input x:\n");
    scanf("%d",&n);
    n=abs(n);
    b=n/100;
    s=n%100/10;
    g=n%100%10;
    printf("y=%d\n",g*100+s*10+b);
    return 0;
}
