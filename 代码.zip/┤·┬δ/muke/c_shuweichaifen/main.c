#include <stdio.h>
#include <stdlib.h>

int main()
{
    int n,a,b,mod;
    float dev;
    printf("Please input n:\n");
    scanf("%d",&n);
    a=n/100;
    b=n%100;
    printf("%d,%d\n",a,b);
    printf("sum=%d,sub=%d,multi=%d\n",a+b,a-b,a*b);
    if(b==0)
    {
        printf("The second operator is zero!\n");
    }
    else
    {
        dev=a*1.0/b;
        mod=a%b;
        printf("dev=%.2f,mod=%d\n",dev,mod);
    }
    return 0;
}
