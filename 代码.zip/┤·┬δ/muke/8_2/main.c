#include <stdio.h>
#include <stdlib.h>

int main()
{
    int n,i,j,k,count=0;
    int *p;
    scanf("%d",&n);
    p=(int*)malloc(sizeof(int)*n);
    int *q;
    q=p;
    for(i=0;i<n;i++)
    {
        scanf("%d",&q[i]);
    }
    for(i=0;i<n;i++)
    {
        for(j=0;j<n;j++)
        {
            for(k=0;k<n;k++)
            {
                if(i!=j&&((q[i]+q[j])==q[k]))
                {
                    count++;
                }
            }
        }
    }
    printf("%d",count/2);
    free(p);
    return 0;
}
