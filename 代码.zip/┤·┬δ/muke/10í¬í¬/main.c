/*#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
long fun(long m,long t,long u,long f,long d,char s[])
{
    int len,i;
    long sum=0;
    len=strlen(s);
    for(i=0;i<len;i++)
    {
        if(s[i]=='u')
        {
            sum+=(u+d);
        }
        else if(s[i]=='f')
        {
            sum+=2*f;
        }
        else if(s[i]=='d')
        {
            sum+=(u+d);
        }
        if(sum>m)
        {
            return (i-1);
        }
    }
    return 0;
}
int main()
{
    long m,t,u,f,d,sum;
    char s[1000];
    printf("Input M,T,U,F,D:");
    scanf("%ld%ld%ld%ld%ld",&m,&t,&u,&f,&d);
    printf("Input conditions of road:");
    getchar();
    gets(s);
    sum=fun(m,t,u,f,d,s);
    printf("num=%ld\n",sum);
    return 0;
}*/
#include <stdio.h>
int main()
{
    FILE *fp;
    int i,k=0,n=0;
    fp=fopen("d1.dat","w");

    if (fp == NULL)
    {
        printf("cannot open the file.\n");
        exit(0);
    }

    for(i=1;i<4;i++)
    {
        fprintf(fp,"%d",i);
    }
    fclose(fp);

    fp=fopen("d1.dat","r");
    if (fp == NULL)
    {
        printf("cannot open infile.\n");
        exit(0);
    }

    fscanf(fp,"%d%d",&k,&n);
    printf("%d %d\n",k,n);
    fclose(fp);
    return 0;
}


