#include <stdio.h>
#include <stdlib.h>

int main()
{
    int t,t_m=0,s_m=0;
    float s,s1,f;
    scanf("%f,%d",&s,&t);
    t_m=(t/5)*2;

    if(s>0&&s<=10)
    {
        if(s<=3)
        {
            s1=0;
        }
        else
        {
            s1=s-3;
        }
        s_m=8+s1*2;
    }
    else if(s>10)
    {
        s1=s-10;
        s_m=8+14+s1*3;
    }
    f=s_m+t_m;
    printf("fee = %d\n",(int)f);
    return 0;
}
