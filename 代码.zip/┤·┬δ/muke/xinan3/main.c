#include <stdio.h>
#include <stdlib.h>

int main()
{
    int n,i,num=0;
    scanf("%d",&n);
    for(i=2; i<n; i++)
    {
        if(n%i!=0)
        {
            num++;
        }
    }
    if(num==n-2)
    {
        printf("sss");
        num=0;
    }
    return 0;
}
