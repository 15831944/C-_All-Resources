#include <stdio.h>
#include <stdlib.h>

int main()
{
    int b_y,t_y,i;
    unsigned long a=0,b=0;
    printf("Input your birth year:");
    scanf("%d",&b_y);
    printf("Input this year:");
    scanf("%d",&t_y);
    for(i=b_y;i<t_y;i++)
    {
        if(i%400==0||(i%4==0&&(i%100!=0)))
           {
               a+=(75*60*24*366);
           }
           else
            {
                b+=(75*60*24*365);
            }
    }
    printf("The heart beats in your life: %lu",a+b);
    return 0;
}
