#include <stdio.h>
#include <stdlib.h>
#include <math.h>
int main()
{
    int a=2,b=3,c=1;
    float x1,x2;
    x1=(-b-sqrt(b*b-4*a*c))*1.0/(2*a);
    x2=(-b+sqrt(b*b-4*a*c))*1.0/(2*a);
    printf("x1=%.4f\nx2=%.4f\n",x2,x1);
    return 0;
}
