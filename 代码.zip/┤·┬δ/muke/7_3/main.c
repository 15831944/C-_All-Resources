#include <stdio.h>
#include <stdlib.h>
int mon(int n)
{
    if(n==1)
    {
        return 1;
    }
    else
    {
        return (mon(n-1)+1)*2;
    }
}
int main()
{
    int n,r;
    printf("Input days n:");
    scanf("%d",&n);
    r=mon(n);
    printf("x=%d\n",r);
    return 0;
}
