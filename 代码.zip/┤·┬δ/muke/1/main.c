#include <stdio.h>
#include <stdlib.h>
int main()
{
    const double c=1.2;
    const double k=4.3;
    const double g=6.4;
    printf("volume=%.3f\n",c*k*g);
    return 0;
}
