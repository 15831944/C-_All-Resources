#include <stdio.h>
#include <stdlib.h>
long Fm(int n)
{
    int t=1,i;
    if(n==0)
    {
        return 1;
    }
    for(i=1; i<=n; i++)
    {
        t*=i;
    }
    return t;
}
long Fact(int m)
{
    int a,b,c;
    a=m/100;
    c=m%10;
    b=(m-a*100)/10;
    if(m==(Fm(a)+Fm(b)+Fm(c)))
    {
        return 1;
    }
    else
    {
        return 0;
    }
}

int main()
{
    int m,t;
    for(m=100; m<1000; m++)
    {
       t= Fact(m);
       if(t==1)
    {
        printf("%d\n",m);
    }
    }

    return 0;
}
