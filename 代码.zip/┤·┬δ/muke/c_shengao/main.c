#include <stdio.h>
#include <stdlib.h>

int main()
{
    int boy_f=175,boy_m=162,girl_f=169,girl_m=153;
    printf("Height of xiao ming:%d\nHeight of xiao hong:%d\n",(int)((boy_f+boy_m)*0.54),(int)((girl_f*0.923+girl_m)/2));
    return 0;
}
