#include <stdio.h>
#include <stdlib.h>
int Gcd(int a, int b)
{
    int c = a%b;
    while(c)
    {
        a = b;
        b = c;
        c = a % b;
    }
    return b;
}
int main()
{
    int m,n,num;
    printf("Input m,n:");
    scanf("%d,%d",&m,&n);
    if(m<1||m>10000||n<1||n>10000)
    {
        printf("Input error!\n");
        return 0;
    }
    num=Gcd(m,n);
    m=m/num;
    n=n/num;
    printf("%d/%d\n",m,n);
    return 0;
}
