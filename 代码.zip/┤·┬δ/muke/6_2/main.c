#include <stdio.h>
#include <stdlib.h>

int main()
{
    FILE *fp,*fp1;
    char num[10],c=' ';
    int n;
    if((fp=fopen("int.txt","r"))==NULL)
    {
        printf("error");
    }
    else
    {
        fp1=fopen("newint.txt","w");
        while(!feof(fp))
        {
            fscanf(fp,"%s",num);
            n=atoi(num);
            if(n%2==0)
            {
                n--;
            }
            else
            {
                n++;
            }
            itoa(n,num,10);
            fputs(num,fp1);
           fputc(c,fp1);
       }

    }

    return 0;
}
