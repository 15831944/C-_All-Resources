#include <stdio.h>

int main()
{
    int n,i,x[50],j;
    char m[50][9];
    scanf("%d",&n);
    for(i=0;i<n;i++)
    {
        scanf("%d %s",&x[i],&m[i]);
    }
    for(i=0;i<n;i++)
    {
        for(j=n-1;j>=0;j--)
        {
            if(x[i]+x[j]==1)
            {
                printf("%s %s",m[i],m[j]);
                x[j]=2;
                x[i]=2;
                if(i!=n/2-1)
                {
                    printf("\n");
                }
            }
        }
    }
    return 0;
}
