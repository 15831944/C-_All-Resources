#include <stdio.h>


int main()
{
    int n,i,m,L[10000],R[10000],a[10000],max,sum=0,j;
    scanf("%d",&n);
    for(i=0;i<n;i++)
    {
        scanf("%d",&a[i]);
    }
    scanf("%d",&m);
    for(i=0;i<m;i++)
    {
        scanf("%d %d",&L[i],&R[i]);
    }
    for(i=0;i<m;i++)
    {
        sum=0;
        if(L[i]<R[i])
        {
            for(j=L[i]-1;j<R[i];j++)
            {
                sum+=a[j];
            }
        }
           if (i==0)
           {
               max=sum;
           }
           if(max<sum)
            {
                max=sum;
            }
    }
     printf("%d",max);
    return 0;
}
