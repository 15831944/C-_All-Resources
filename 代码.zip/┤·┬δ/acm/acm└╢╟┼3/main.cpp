#include <stdio.h>
#include <stdlib.h>
#include <math.h>
int main()//double ֻ�ܱ���16λ������������Զ��������룬����20λ��ֽ��һ����
{
     int z[100],m[100],z1[99],m1[99],n,i,j,a,b,num=0;
     scanf("%d",&n);
     for(i=0;i<n;i++)
     {
         scanf("%d %d",&z[i],&m[i]);
     }
     for(i=0;i<n-1;i++)
     {
         if((z[i]<0&&m[i]<0)||(z[i+1]<0&&m[i+1]<0))
         {
                z[i]=-z[i];
                m[i]=-m[i];
         }
        else if(z[i]<0||m[i]<0||z[i+1]<0||m[i+1]<0)
        {
                z[i]=abs(z[i]);
                m[i]=abs(m[i]);
                z[i+1]=abs(z[i+1]);
                m[i+1]=abs(m[i+1]);
                num=1;
        }
         z1[i]=z[i]*z[i+1];
         m1[i]=m[i]*m[i+1];
         b=z1[i];
         for(j=1;j<=20;j++)
         {
             a=b/m1[i];
             b=b%m1[i]*pow(10,1);
            if(num==1)
            {
              printf("-");
              num=0;
            }
             if(j==1)
             printf("%d.",a);
             else
             printf("%d",a);
         }
         printf("\n");
     }

    return 0;
}
