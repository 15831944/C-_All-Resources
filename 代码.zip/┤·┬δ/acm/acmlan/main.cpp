#include <stdio.h>
int function(int a)
{
    int num=0,i,flag=0;
    if(a==2)
        num=2;
    else
    {
        for(i=2;i<a;i++)
        {
            if(a%i!=0)
            {
                flag++;
            }
        }
        if(flag==a-2)
        {
            num=a;
        }
    }
    return num;
}
int main()
{
    int n,a,b[20],i,j=0,num[20],ans;
    scanf("%d",&n);
    for(i=0;i<n;i++)
    {
        scanf("%d",&b[i]);
    }
    for(i=0;i<n;i++)
    {
        a=function(b[i]);
        if(a!=0)
        {
            num[j]=i+1;
            j++;
        }
    }
    if(j>1)
    {
    ans=num[1]-num[0];
    for(i=1;i<j-1;i++)
    {
        if(ans<(num[i+1]-num[i]))
        {
            ans=num[i+1]-num[i];
        }
    }
    }
    else if(j==0)
    {
        ans=n+1 ;
    }
    else if(j==1)
    {
        if(n-num[0]>(num[0]))
        {
            ans=n-num[0];
        }
        else
            ans=num[0];
    }
    printf("%d",ans);
        return 0;
}
