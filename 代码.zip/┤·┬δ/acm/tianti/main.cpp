#include <stdio.h>
#include <stdlib.h>
#include <string.h>
int main()
{
    int num,i,len,h=1,sum=0;
    double zhi,m=1.0;
    char n[50];
    gets(n);
    len=strlen(n);
    if(n[0]=='-')
    {
        m+=0.5;
        len=len-1;
    }
    for(i=0;i<len;i++)
    {
        if(n[i]=='2')
        {
            sum++;
        }
    }
    num=atoi(n);
    if(num%2==0)
    {
        h++;
    }
    zhi=sum*1.0/len*1.0*m*h*100;
    printf("%.2lf%%",zhi);
    return 0;
}
