#include <stdio.h>
int main()
{   int Y,M,D,i,n=0,c=0;
    int a[12]={31,29,31,30,31,30,31,31,30,31,30,31};
    int b[12]={31,28,31,30,31,30,31,31,30,31,30,31};
    while(scanf("%d/%d/%d",&Y,&M,&D)!=EOF){
       n=0;
       c=0;
       if(M==1)
        {
         c=D;
        }
      else if((Y%4==0&&Y%100!=0)||Y%400==0)
      {
      for(i=0;i<M-1;i++)
        {
        n+=a[i];
        c=n+D;
        }
     }
     else
        {
            for(i=0;i<M-1;i++)
            {
                n+=b[i];
                c=n+D;
            }
        }
        printf("%d\n",c);
}


    return 0;
}
