#include <stdio.h>
#include <stdlib.h>

int main()
{
    int n,i,j,tr[1010],num[1010],m,ch[1010];
    char zun[1010][20];
    scanf("%d",&n);
    for(i=0;i<n;i++)
    {
        getchar();
        scanf("%s %d %d",zun[i],&tr[i],&num[i]);
    }
    scanf("%d",&m);
    for(i=0;i<m;i++)
    {
        scanf("%d",&ch[i]);
    }
    for(i=0;i<m;i++)
    {
        for(j=0;j<n;j++)
        {
            if(ch[i]==tr[j])
            {
                printf("%s %d\n",zun[j],num[j]);
            }
        }
    }
    return 0;
}
