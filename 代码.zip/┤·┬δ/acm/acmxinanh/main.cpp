#include <stdio.h>

int main()
{
    int n,i;
    while(scanf("%d",&n)!=EOF)
    {
        for(i=1; i<=n; i++)
        {
            if(i!=n)
                printf("gu...");
            else
                printf("gu...\n");

        }
        printf("The story is so boring. And I am so hungry!\n");
    }
    return 0;
}
