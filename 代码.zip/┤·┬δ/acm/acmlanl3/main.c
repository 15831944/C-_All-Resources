#include <stdio.h>
#include <stdlib.h>

int main()
{
    int a[30][30],i,j;
     for(i=1;i<=28;i++)
     {
         for(j=1;j<=i;j++)
         {
             scanf("%d",&a[i][j]);
         }
     }
    for(i=1;i<=28;i++)
    {
        for(j=1;j<=i;j++)
        {
            a[i+1][j]=a[i][j]/2+a[i][j-1]/2;
        }
        if(i==28)
        {
            for(j=1;j<=28;j++)
            {
                printf("%d ",a[i][j]);
            }
        }
    }
    return 0;
}
