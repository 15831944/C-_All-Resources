#include <stdio.h>

int main()
{
    int t,n,a[1000],b[1000],i,j,m=0,h,flag=0;
    scanf("%d",&t);
    for(h=0; h<t; h++)
    {
        flag=0;
        scanf("%d",&n);
        for(i=0; i<n; i++)
        {
            scanf("%d",&a[i]);
        }
        for(i=0; i<n; i++)
        {
            m=0;
            for(j=0; j<n; j++)
            {
                if(a[j]>=a[i])
                {
                    m++;
                }
                b[i]=m;
            }
        }
        for(i=0; i<n; i++)
        {
            if(b[i]==n)
            {
                flag++;
            }
            if(flag==n)
            {
                if(i!=n-1)
              printf("%d\n",a[1]);
              else
              printf("%d",a[1]);
            }
            else if(a[i]!=b[i])
            {
                if(i==n-1)
                    printf("%d\n",b[i]);
                else
                    printf("%d",b[i]);
            }
        }
    }
    return 0;
}
