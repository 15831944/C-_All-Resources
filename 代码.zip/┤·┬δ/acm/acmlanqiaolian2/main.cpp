#include <stdio.h>

int main()//int的最大值是2∗109,所以这道题需要用longlong存数据
{
   int a[8],i,j,n,m;
   long long int sum=0;
   for(i=0;i<8;i++)
   {
       scanf("%d",&a[i]);
       sum+=a[i];
   }
   if(sum%2!=0)
   {
       printf("No");
       return 0;
   }
   for(i=0;i<8;i++)
   {
       for(j=0;j<8;j++)
       {
           if(j!=i)
            {
                for(m=0;m<8;m++)
               {
                   if(m!=i&&m!=j)
                   {
                       for(n=0;n<8;n++)
                       {
                           if(n!=i&&n!=j&&n!=m)
                           {
                               if(a[i]+a[j]+a[m]+a[n]==(sum/2))
                               {
                                   printf("Yes");
                                   return 0;
                               }
                           }
                       }
                   }
               }
            }
       }
   }
   printf("No");
       return 0;
}
