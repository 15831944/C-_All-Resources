#include <stdio.h>

int main()
{
    int N,K,i=1,o[10000];
    scanf("%d %d",&N,&K);
        if(i==1){
            scanf("%d",&o[i]);
            i++;
        }
        for(i=2;i<=N;i++)
            {
        scanf(" %d",o[i];
        }

    return 0;
}
