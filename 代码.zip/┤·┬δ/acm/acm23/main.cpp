#include <stdio.h>
int main()
{
    int m,n,i,j,a[100][100],c,e,f,g,s;
    double b[100][100];
     while(scanf("%d %d",&n,&m))
    {
        e=0;
        s=0;
        for(i=1;i<=n;i++)
        {
             c=0;
            for(j=1;j<=m;j++)
            {
                scanf("%d",&a[i][j]);
                c+=a[i][j];
            }
            b[1][i]=c*1.0/m;
        }
        for(g=1;g<=m;g++)
        {
            f=0;
            for(i=1;i<=n;i++)
            {
                f+=a[i][g];
            }
            b[2][g]=f*1.0/n;
        }
        for(i=1;i<=n;i++)
        {     e=0;
            for(j=1;j<=m;j++)
            {
                if(a[i][j]>=b[2][j])
                {
                    e++;
                }
                if(e==m)
                    s++;
            }
        }
        for(i=1;i<=n;i++)
        {
            if(i==1)
            printf("%.2f",b[1][i]);
            else
            printf(" %.2f",b[1][i]);
        }
        printf("\n");
        for(g=1;g<=m;g++)
        {
            if(g==1)
            printf("%.2f",b[2][g]);
            else
            printf(" %.2f",b[2][g]);
        }
        printf("\n");
        printf("%d\n",s);
          }


    return 0;
}
