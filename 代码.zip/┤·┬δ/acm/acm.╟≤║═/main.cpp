#include <stdio.h>
#include<math.h>
int main()
{
    int m,n,i,a;
    double sum=0.0;
    scanf("%d",&m);
    for(i=0;i<m;i++)
    {
        sum=0.0;
        scanf("%d",&n);
        for(a=1;a<=n;a++)
            {
                sum+=pow(-1,a+1)*1.0/a;

        }
        printf("%.2lf\n",sum);
    }


    return 0;
}
