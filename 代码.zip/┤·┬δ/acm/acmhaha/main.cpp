#include <stdio.h>
#include <string.h>
#include <math.h>
int main()
{
    int i,num=0,num1=0,len,j;
    char a[1000]={0};
    gets(a);
    for(i=0;i<1000;i++)
    {
        if(a[i]==0)
        {
            len=i-1;
            break;
        }
    }
    for(i=0;i<len;i++)
    {
        for(j=len;j>0;j--)
        {
            num+=a[i]*pow(10,j-1);
        }
        num1+=a[i];
    }
    printf("%d %d",num,num1);
    if(num%num1==0)
    {
        printf("Yes");
    }
    else
    {
        printf("No");
    }
    return 0;
}
