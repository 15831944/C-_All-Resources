#include <stdio.h>

int main()
{
    int A,B,C,D;
    scanf("%d",&A);
    scanf("%d",&B);
    scanf("%d",&C);
    scanf("%d",&D);
    if(A==B&&B==C)
        printf("D");
    if(A==B&&B==D)
        printf("C");
    if(A==C&&C==D)
        printf("B");
    if(B==C&&C==D)
        printf("A");
    return 0;
}
