#include <stdio.h>

int main()
{
    int k,n,i,j=0,flag=0,b=0;
    char s[26],a[26];
    scanf("%d %d",&n,&k);
    for(i=0;i<n;i++)
    {
        scanf("%c",&s[i]);
        a[i]='A'+j;
        j++;
    }
    if(n==1)
    {
        printf("Yes");
        return 0;
    }
    else if(n<=k)
    {
        printf("Yes");
        return 0;
    }
    else if(n>k)
    {
         for(i=0;i<n;i++)
       {
          for(j=i+1;j<n;j++)
          {
           if(s[i]==s[j])
           {
               flag=1;
           }
          }
          if(flag==0)
          {
              k+=1;
              b=1;
          }
          if(s[i]>a[k-1])
          {
              printf("No");
              return 0;
          }
          flag=0;
        }
       printf("Yes %d %d",k,b);
    }
    return 0;
}
