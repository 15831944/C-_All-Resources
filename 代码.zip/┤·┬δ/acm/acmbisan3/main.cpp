#include <stdio.h>

int main()
{
    int n,i,a;
    scanf("%d",&n);

    if(n%2!=0)
    {
         if(n==3)
        {
            printf("5");
            return 0;
        }
        a=(n+1)/2-1;
        i=(1+n-2)*a+n;
    }
    else
    {
         if(n==2)
        {
            printf("2");
            return 0;
        }

        a=n/2-1;
        i=(2+n-2)*a+n;
    }
    printf("%d",i);

    return 0;
}
