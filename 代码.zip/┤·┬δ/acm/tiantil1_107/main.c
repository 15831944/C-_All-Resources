#include <stdio.h>
#include <stdlib.h>
#include <string.h>
int main()
{
    char num[52];
    int i,len,num_,num_2=0;
    double n1=1,n2=1,re;
    scanf("%s",num);
    num_=atoi(num);
    len=strlen(num);
    if(num[0]=='-')
    {
        n1+=0.5;
        len-=1;
    }
    if(num_%2==0)
    {
        n2+=1;
    }
    for(i=0;i<len;i++)
    {
        if(num[i]=='2')
        {
            num_2++;
        }
    }
    re=num_2*1.0/len*n1*n2*100;
    printf("%.2f%%",re);
    return 0;
}
