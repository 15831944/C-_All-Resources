#include <stdio.h>
#include<stdlib.h>
int main()
{
    int x,y,m,n,i,j,a[100][100],max;
    while(scanf("%d %d",&m,&n)!=EOF)
    {
        for(i=1;i<=m;i++)
        {
            for(j=1;j<=n;j++)
            {
                scanf("%d",&a[i][j]);
            }
        }
        max=a[1][1];
        x=1;
        y=1;
        for(i=1;i<=m;i++)
        {
            for(j=1;j<=n;j++)
            {
                if(abs(max)<abs(a[i][j]))
                {
                    max=a[i][j];
                    x=i;
                    y=j;
                }
            }
        }
        printf("%d %d %d\n",x,y,max);
    }
    return 0;
}
