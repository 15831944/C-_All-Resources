#include <stdio.h>
#include <stdlib.h>

int main()
{
    int i,n=0,j;
    for(i=2;i<=1000;i++)
    {
        n=0;
        for(j=2;j<i;j++)
        {
            if(i%j!=0)
            {
                n++;
            }
        }
        if(n==i-2)
        {

        }
    }
    return 0;
}
