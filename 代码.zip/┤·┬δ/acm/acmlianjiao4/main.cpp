#include <stdio.h>
#include <stdlib.h>
int main()//当|r−g|≤1的时候输出YES(r=0,g=0的时候特判NO)其他情况输出NO
{
    int r,g;
    scanf("%d %d",&r,&g);
    if(r==0&&g==0)
        printf("No");
    else if(abs(r-g)==1)
    {
        printf("Yes");
    }
    else
        printf("No");
    return 0;
}
