#include <stdio.h>
int main()
{
    int n,i,c,d;
 while(scanf("%d",&n)!=EOF)
 {
        if(n==0)
        return 0;
     int a[10000]={0,1};
      c=1;
      d=1;
   for(i=2;i<=n;i++)
   {
       for(;c<=4;c++)
       {
           a[i]=a[i-1]+d;
           if(c==4)
           {
               d++;
               c=0;
           }
           else{
               c+=1;
               break;
           }
       }
   }
   printf("%d\n",a[n]);
 }
    return 0;
}
