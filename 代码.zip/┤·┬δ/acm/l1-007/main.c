#include <stdio.h>
#include <stdlib.h>
#include <string.h>
int main()
{
    int i,len,n1;
    char n[1000],num[10][10]=
    {
        "ling",
        "yi",
        "er",
        "san",
        "si",
        "wu",
        "liu",
        "qi",
        "ba",
        "jiu"
    };
    gets(n);
    len=strlen(n);
    for(i=0; i<len; i++)
    {
        if(n[0]=='-')
        {
            if(i==0)
            printf("fu");
            if(i!=0)
            {
              n1=n[i]-'0';
              printf(" %s",num[n1]);
            }
        }
        else
        {
            n1=n[i]-'0';
            if(i==0)
            {
                printf("%s",num[n1]);
            }
            else
            {
                printf(" %s",num[n1]);
            }
        }
    }
    return 0;
}
