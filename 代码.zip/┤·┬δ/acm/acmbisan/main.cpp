#include <stdio.h>
int main()
{
    int x,y,z,a;
    for(x=1;x<=9;x++)
    {
        for(y=9;y>=0;y--)
        {
            for(z=0;z<=9;z++)
            {
                  a=x*100+y*10+z+y*100+z*10+z;
                  if(a==532)
                  {
                      printf("%d %d %d\n",x,y,z);
                  }
            }
        }
    }

    return 0;
}
