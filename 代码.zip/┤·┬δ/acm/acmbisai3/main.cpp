#include <stdio.h>
int main()
{
  int n,x,y,i,b;
  char a;
  scanf("%d",&n);
  b=0;
  x=0;
  y=0;
  for(i=1;i<=n;i++)
  {
      scanf("%c",&a);
      if(a=='U')
      {

          y=y+1;
          if(x==0&&y==0)
          {
              b=i;
          }
      }
      else if(a=='D')
      {

          y=y-1;
          if(x==0&&y==0)
          {
              b=i;
          }

      else if(a=='L')
      {

          x=x-1;
          if(x==0&&y==0)
          {
              b=i;
          }
      }
      else if(a=='R')
      {

          x=x+1;
          if(x==0&&y==0)
          {
              b=i;
          }
      }
  }
  if(b==0)
    printf("0");
  else
    printf("%d",b);
    return 0;
}
