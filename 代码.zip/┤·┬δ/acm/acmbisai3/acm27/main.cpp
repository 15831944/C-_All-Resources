#include <stdio.h>
#include <string.h>
int main()
{
    int num1,num2,num3,num4,num5,n,len,i;
    char a[100];
    scanf("%d",&n);
    getchar();
   while(n--)
   {
       num1=0;
       num2=0;
       num3=0;
       num4=0;
       num5=0;
       gets(a);
      len=strlen(a) ;
      for(i=0;i<len;i++)
      {
          if(a[i]=='a')
          {
              num1++;
          }
          else if(a[i]=='e')
          {
              num2++;
          }
          else if(a[i]=='i')
          {
              num3++;
          }
          else if(a[i]=='o')
          {
              num4++;
          }
          else if(a[i]=='u')
          {
              num5++;
          }
      }
      printf("a:%d\n",num1);
      printf("e:%d\n",num2);
      printf("i:%d\n",num3);
      printf("o:%d\n",num4);
      printf("u:%d\n",num5);
    if(n!=0)
    printf("\n");
   }

    return 0;
}
