#include <stdio.h>

int main()
{
    int n,i,a,b,c,d;
    scanf("%d",&n);
    for(i=2;i<n;i++)
    {
        if(2*n==i*(i+1))
        {
            if(i%2!=0)
            {
                printf("1/%d",i);
                return 0;
            }
            else
                printf("%d/1",i);
            return 0;
        }
        a=i*(i-1);
        b=(i+1)*(i+2);
        if(a<2*n&&b>2*n)
        {
            c=i+1;
            break;
        }
    }
    d=n-(i+1)*i/2-1;
    printf("%d %d %d %d\n",d,a,b,c);
    if(c%2!=0)
    {
        printf("%d/%d",(c-d),(1+d));
    }
    else
        printf("%d/%d",(1+d),(c-d));

    return 0;
}
