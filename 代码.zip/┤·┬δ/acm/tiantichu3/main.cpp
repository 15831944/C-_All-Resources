#include <stdio.h>

int main()
{
    int i,j,y,n,sum1=0,sum2=0,jh[100],jhu[100],yh[100],yhu[100],num;
    scanf("%d %d",&j,&y);
    scanf("%d",&n);
    for(i=0;i<n;i++)
    {
        scanf("%d %d %d %d",&jh[i],&jhu[i],&yh[i],&yhu[i]);
    }
    for(i=0;i<n;i++)
    {
        num=jh[i]+yh[i];
        if(jhu[i]==num)
        {
            sum1++;
        }
        if(yhu[i]==num)
        {
            sum2++;
        }
        if(jhu[i]==num&&yhu[i]==num)
        {
            sum1--;
            sum2--;
        }
         if(sum1>j)
        {
            printf("A\n");
            printf("%d",sum2);
            return 0;
        }
        if(sum2>y)
        {
            printf("B\n");
            printf("%d",sum1);
            return 0;
        }
    }
    return 0;
}
