#include <stdio.h>

int main()
{
    int n,a[100],i,j=0,flag=0,sum=0,m=0;
    scanf("%d",&n);
    for(i=0;i<n;i++)
    {
        scanf("%d",&a[i]);
        if(a[i]%2==0)
        {
            flag+=a[i]/2;
        }
            sum+=a[i];

    }
    for(i=0;i<n;i++)
    {
        if(a[i]%2!=0)
        {
            m++;
            if(a[i]==1)
            {
               j++;
            }
        }
    }
    if(j==n)
    {
        printf("1");
    }
    else if(m<=flag)
        printf("%d",sum);
    else if(m>flag)
        printf("%d",flag+flag/2);

    return 0;
}
