#include <stdio.h>
int main()
{
    int N,K,n,i,a=0,b=0;
    n=1;
    scanf("%d",&N);
    scanf("%d",&K);
    for(i=1; i<=N; i++)
    {
        a=n*2;
        b=n+K;
        if(a<=b)
        {
            n=a;
        }
        else
        {
            n=b;
        }
    }
    printf("%d\n",n);
    return 0;
}
