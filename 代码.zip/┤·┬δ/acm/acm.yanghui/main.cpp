#include <stdio.h>

int main()
{
    int i,n,j,a[100][100];
    while(scanf("%d",&n)!=EOF)
        {
            a[1][1]=1;
            for(i=2;i<=n;i++)
            {
                for(j=1;j<=i;j++)
                {
                    a[i][j]=a[i-1][j]+a[i-1][j-1];
                }
            }
            for(i=1;i<=n;i++)
            {
                printf("%d",a[i][1]);
                for(j=2;j<=i;j++)
                {
                    printf(" %d",a[i][j]);
                }
                printf("\n");
            }
            printf("\n");
       }
       return 0;
}
