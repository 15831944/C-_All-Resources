#include <stdio.h>

int main()
{
    int m,n,p[100],a[2000],c[100],d[100],i,j,t,sum=0;
    scanf("%d %d",&n,&m);
    for(i=0;i<m;i++)
    {
        scanf("%d %d",&p[i],&a[i]);
        c[i]=p[i];
    }
    for(i=0;i<m;i++)
    {
        for(j=0;j<m-i-1;j++)
        {
            if(c[j]>c[j+1])
            {
              t=c[j+1];
              c[j+1]=c[j];
              c[j]=t;
            }
        }
    }
    for(i=0;i<m;i++)
    {
        for(j=0;j<m;j++)
        {
            if(c[i]==p[j])
            {
                d[i]=j;
            }
        }
    }
        for(i=0;i<m;i++)
        {
            j=d[i];
            if(n-a[j]>=0)
            {
                sum+=a[j]*p[j];
                n=n-a[j];
            }
            else if(n-a[j]<0)
            {
                sum+=p[j]*n;
                break;
            }
        }
      printf("%d",sum);
     return 0;
}
