#include <stdio.h>
int main()
{
    int n,i,m,j,sum=0,num1,num2,num3;
    scanf("%d",&n);
    if(n%2==0)
        j=n/2;
    else
    j=(n-1)/2;
    for(i=n;i>=j;i--)
    {
            num1=1;
            num2=1;
            num3=1;
            for(m=1;m<=i+1;m++)
            {
                num1*=m;
            }
            for(m=1;m<=n-i;m++)
            {
                num2*=m;
            }
            for(m=1;m<=(2*i-n+1);m++)
            {
                num3*=m;
            }
            sum+=num1/(num2*num3);
    }
    printf("%d",sum);
    return 0;
}
