#include <stdio.h>
#include <string.h>
int main ()
{

    int n,i,len,m;
    char a[100],b[100];
    scanf("%d",&n);
    getchar();
    while(n--)
    {
        m=0;
       gets(a);
       len=strlen(a);
       for(i=0;i<len;i++)
       {
           b[i]=a[i];
       }
        for(i=0;i<len;i++)
        {
            a[i]=a[len-1-i];
            a[len-1-i]=b[i];
        }
        for(i=0;i<len;i++)
        {
            if(b[i]==a[i])
            {
                m++;
            }
        }
        if(m==len)
        {
            printf("yes\n");
        }
        else
            printf("no\n");
    }
    return 0;
}
