#include <stdio.h>
#include <stdlib.h>
int main()
{
    int a,b,sum=0,i,num=0;
    scanf("%d %d",&a,&b);
        for(i=a; i<=b; i++)
        {
            num++;
            printf("%5d",i);
            if(num%5==0)
            {
                printf("\n");
            }
            sum+=i;
        }
        if(num!=0)
        printf("\n");
        printf("Sum = %d",sum);
    return 0;
}
/*#include <stdio.h>
#include <stdlib.h>
int main() {
    int n,m,i;
    scanf("%d %d",&n,&m);
    int sum = 0;
    int num = 0;
    for (i = n; i <= m; i++) {
        sum+=i;
        num++;
        printf("%5d",i);
        if (num == 5) {
            num = 0;
            printf("\n");
        }
    }
    if (num != 0) {
        printf("\n");
    }
    printf("Sum = %d\n",sum);
    return 0;
}*/
