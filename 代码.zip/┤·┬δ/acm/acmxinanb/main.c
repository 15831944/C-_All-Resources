#include <stdio.h>
#include <stdlib.h>
#include <string.h>
int main()
{
    int num=0,i,len;
    char a[10000];
    gets(a);
    len=strlen(a);
    for(i=0;i<len;i++)
    {
        if(a[0]==a[i])
        {
            num++;
        }
    }
    if(num==len)
        printf("Yes");
    else
        printf("No");
    return 0;
}

