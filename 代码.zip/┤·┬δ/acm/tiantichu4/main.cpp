#include <stdio.h>

int main()
{
    int l=0,n,k[100],num[100][1000],m,m1[10000],i,j,sum1=0,sum2=0,f,flag=0,flag1=0,r[10000];
    scanf("%d",&n);
    for(i=0;i<n;i++)
    {
        scanf("%d",&k[i]);
        for(j=0;j<k[i];j++)
        {
            scanf("%d",&num[i][j]);
        }
    }
    scanf("%d",&m);
    for(i=0;i<m;i++)
    {
        scanf("%d",&m1[i]);
    }
    for(i=0;i<m;i++)
    {
        sum1=0;
        sum2=0;
        for(f=0;f<n;f++)
        {
            for(j=0;j<k[f];j++)
            {
                if(m1[i]!=num[f][j])
                {
                    sum1++;
                }
            }
        }
        for(j=0;j<n;j++)
        {
            sum2+=k[j];
        }
        if(sum1==sum2)
        {
            flag=1;
            r[l]=m1[i];
            l++;
        }
    }
    if(flag==0||n==0)
    {
        printf("No one is handsome");
        return 0;
    }
    else
    {
        for(i=0;i<l;i++)
        {
            for(j=l-1;j>=0;j--)
            {
                if(i!=j&&r[i]==r[j]&&i<=j)
                {
                    r[j]=0;
                }
            }
        }
        for(i=0;i<l;i++)
        {
            if(r[i]!=0&&flag1==0)
            {
                printf("%d",r[i]);
                flag1=1;
            }
           else if(r[i]!=0&&flag1!=0)
            {
                printf(" %d",r[i]);
            }
        }
    }
    return 0;
}
