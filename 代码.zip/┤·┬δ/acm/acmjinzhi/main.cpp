#include <stdio.h>
#include <math.h>
int main()
{
    int i,m,n,r,flag=0,len,a=0;
    char num[50];
    while(scanf("%d %d",&n,&r)!=EOF)
    {
        flag=0;
        i=0;
        a=0;
        if(n<0)
        {
            n=fabs(n);
            a=1;
        }
         if(r<10)
        {
            while(flag==0)
            {
                num[i]=n%r;
                m=n/r;
                n=m;
                i++;
                if(m==0)
                {
                    flag=1;
                }
            }
        }
        else if(r>10)
        {
            while(flag==0)
            {
                num[i]=n%r;
                if(num[i]>=10)
                {
                    if(n%r==10)
                        num[i]='A';
                    else if(n%r==11)
                        num[i]='B';
                    else if(n%r==12)
                        num[i]='C';
                    else   if(n%r==13)
                        num[i]='D';
                    else   if(n%r==14)
                        num[i]='E';
                    else  if(n%r==15)
                        num[i]='F';
                }
                m=n/r;
                n=m;
                i++;
                if(m==0)
                {
                    flag=1;
                }
            }
        }
        len=i-1;
        if(a==1)
            {
                printf("-");
            }
        for(i=len;i>=0;i--)
        {
            if(num[i]>='A'&&num[i]<='F')
            {
                printf("%c",num[i]);
            }
            else
                printf("%d",num[i]);
        }
        printf("\n");
    }
    return 0;
}
