#include <stdio.h>

int main()
{  int n,i,j,a[10000],s,t;
double p;
while(scanf("%d",&n)!=EOF)
{
    s=0;
    p=0;
    for(i=0;i<n;i++)
    {
        scanf("%d",&a[i]);
    }
    for(i=0;i<n;i++)
    {
        for(j=0;j<n-1-i;j++)
        {
            if(a[j]>a[j+1])
            {
                t=a[j];
                a[j]=a[j+1];
                a[j+1]=t;
            }
        }
    }
    for(i=1;i<=n-2;i++)
    {
        s+=a[i];
    }
    p=1.0*s/(n-2);
    printf("%.2f\n",p);
}
    return 0;
}
