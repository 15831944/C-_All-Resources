#include <stdio.h>

int main()
{ int N;
int A,B,C,i,s=0;
scanf("%d",&N);
scanf("%d",&A);
scanf("%d",&B);
scanf("%d",&C);
for(i=1;i<=n;i++)
    {
    if(A>=B){
        s+=B;
        i++;
        if()
            {
            s+=A;
            i++;
            if(A>C){
                s+=c;
                i++;
               else{
                s+=A;
                i++;
               }
            }

        }
        if(B>C){
            S+=C;
            i++;
            if(C>A){
                s+=A;
                i++;
            }
        }
        }
        else
            s=A;


}

    return 0;
}
