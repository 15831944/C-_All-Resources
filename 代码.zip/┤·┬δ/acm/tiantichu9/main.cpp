#include <stdio.h>

int main()
{
    int n1,k[10000],n[10000][20],p[10000][20],i,j,sum[10]= {0},sum1[10],sum2[10]= {0},num=0,num1[10]= {1,2,3,4,5,6,7,8,9,10},t;
    scanf("%d",&n1);
    for(i=0; i<n1; i++)
    {
        scanf("%d",&k[i]);
        for(j=0; j<k[i]; j++)
        {
            scanf("%d %d",&n[i][j],&p[i][j]);
        }
    }
    for(i=0; i<n1; i++)
    {
        for(j=0; j<k[i]; j++)
        {
            sum[i]+=p[i][j];
        }
    }
    for(i=0; i<n1; i++)
    {
        for(j=0; j<k[i]; j++)
        {
            num=n[i][j];
            sum[num]-=p[i][j];
            sum2[num]++;
        }
    }
    for(i=0; i<10; i++)
    {
        sum[i]=-sum[i];
        sum1[i]=sum[i];
    }
    for(i=0; i<10; i++)
    {
        for(j=0; j<9-i; j++)
        {
            if(sum1[i]<sum1[j])
            {
                t=sum1[j];
                sum1[j]=sum1[i];
                sum1[i]=t;
                num1[i]=j+1;
                num1[j]=i+1;
            }
        }
    }
    for(i=0; i<10; i++)
    {
        for(j=0; j<10; j++)
        {
            if(i!=j)
            {
                if(sum1[i]==sum1[j])
                {
                    if(sum2[i]>sum2[j])
                    {
                        if(i>j)
                        {
                            t= num1[i];
                            num1[i]=num1[j];
                            num1[j]=t;
                        }
                    }
                    else if(sum2[i]==sum2[j])
                    {
                        if(i>j)
                        {
                            t=num1[j];
                            num1[j]=num1[i];
                            num1[i]=t;
                        }
                    }

                }
            }
        }
    }
    for(i=0; i<10; i++)
    {
        printf("%d %.2f\n",num1[i],sum1[num1[i]]*0.01);
    }
    return 0;
}
