#include <stdio.h>
#include <string.h>
int main()
{
    int n,i,len,m,s;
    char a[10000];
    scanf("%d",&n);
    getchar();
    while(n--)
    {
        m=0;
        s=0;
        gets(a);
        len=strlen(a);
        for(i=0;i<len;i++)
        {
            if(a[i]<0)
            {
              m++;
            }
        }
        printf("%d\n",m/2);
    }
    return 0;
}
