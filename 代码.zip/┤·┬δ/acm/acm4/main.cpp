#include <stdio.h>
#include <math.h>
int main()
{
    int i,n,m;

   double a,c,b=0.00;

   while(scanf("%d %d",&n,&m)!=EOF)
   {
       b=0.00;

    for(i=0;i<m;i++)
    {
        a=pow(2,-i);

        c=pow(n,a);

        b+=c;
    }
    printf("%.2lf\n",b);

}
    return 0;

}
