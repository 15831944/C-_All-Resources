#include <stdio.h>

int main()
{
    int n,i,num_a=0,num_b=0;
    char a[5],b[5],A[1000],B[1000];
    scanf("%d",&n);
    for(i=0;i<n;i++)
    {
        scanf("%s",&a[5]);
        getchar();
        scanf("%s",&b[5]);
        A[i]=a[0];
        B[i]=b[0];
        printf("%c %c\n",A[i],B[i]);
    }
    for(i=0;i<n;i++)
    {
        if(A[i]==B[i])
        {
            num_a=num_a+1;
            num_b=num_b+1;
        }
        else if(A[i]=='J'&&B[i]=='M')
        {
            num_a=num_a+3;
        }
        else if (A[i]=='M'&&B[i]=='T')
        {
            num_a=num_a+3;
        }
        else if (A[i]=='T'&&B[i]=='S')
        {
            num_a=num_a+3;
        }
        else if (A[i]=='S'&&B[i]=='H')
        {
            num_a=num_a+3;
        }
        else if (A[i]=='H'&&B[i]=='J')
        {
            num_a=num_a+3;
        }
        else if (A[i]=='M'&&B[i]=='J')
        {
            num_b=num_b+3;
        }
        else if (A[i]=='T'&&B[i]=='M')
        {
            num_b=num_b+3;
        }
        else if (A[i]=='S'&&B[i]=='T')
        {
            num_b=num_b+3;
        }
        else if (A[i]=='H'&&B[i]=='S')
        {
            num_b=num_b+3;
        }
        else if (A[i]=='J'&&B[i]=='H')
        {
            num_b=num_b+3;
        }
    }
    if(num_a>num_b)
        printf("Alice");
    else if(num_a<num_b)
        printf("Bob");
    else
        printf("Draw");
    return 0;
}
