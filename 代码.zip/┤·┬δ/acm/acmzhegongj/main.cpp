#include <stdio.h>
int main()
{
    int i,t,a[1000],num,b1[1000],b2[1000],h[10]={2,0,3,3,1,3,3,1,3,3},s[10]={4,2,2,2,3,2,3,2,4,3};
    scanf("%d",&t);
    for(i=0;i<t;i++)
    {
        scanf("%d",&a[i]);
    }
    for(i=0;i<t;i++)
    {
        num=a[i];
        b1[i]=h[num];
        b2[i]=s[num];
    }
    for(i=0;i<t;i++)
    {
        if(i!=t-1)
        printf("%d %d\n",b1[i],b2[i]);
        else
            printf("%d %d",b1[i],b2[i]);
    }
    return 0;
}
