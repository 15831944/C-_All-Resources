#include <stdio.h>
int main()
{
   long int n,m,i;
    scanf("%ld %ld",&n,&m);
    i=n+(n+1)*m;
    printf("%ld",i);
    return 0;
}
