
#include <stdio.h>
int main()
{
    int n,r,i,flag=0;
    char a[1000];
    scanf("%d %d",&n,&r);
    if(n<0)
    {
        flag=1;
        n=-n;
    }
    if(r>10)
    {
        for(i=0;;i++)
        {
            if(n%r==10)
                a[i]='A';
            else if(n%r==11)
                a[i]='B';
            else if(n%r==12)
                a[i]='C';
            else   if(n%r==13)
                a[i]='D';
            else   if(n%r==14)
                a[i]='E';
            else  if(n%r==15)
                a[i]='F';
          else if(n%r<10)
          {
               for(i=0;; i++)
        {
            a[i]=n%r;
            n=n/r;
            if(n==0)
                break;
        }
              if(flag==1)
        {
            printf("-");
    for(; i>=0; i--)
    {

        printf("%d",a[i]);
    }
    printf("\n");
        }
        return 0;
          }


        }
    }
      else if(r<10)
    {
        for(i=0;; i++)
        {
            a[i]=n%r;
            n=n/r;
            if(n==0)
                break;
        }
    if(flag==1)
        {
            printf("-");
    for(; i>=0; i--)
    {

        printf("%d",a[i]);
    }
    printf("\n");
        }
        return 0;
          }
}
