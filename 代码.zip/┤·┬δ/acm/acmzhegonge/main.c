#include <stdio.h>
#include <stdlib.h>

int main()
{
    int t ,a[1000],b[1000],c[1000],d[1000],i,cha1[1000],cha2[1000];
    scanf("%d",&t);
    for(i=0;i<t;i++)
    {
        scanf("%d %d %d %d",&a[i],&b[i],&c[i],&d[i]);
        cha1[i]=a[i];
        cha2[i]=b[i];
    }
    for(i=0;i<t;i++)
    {
        while(1)
        {
            cha1[i]=cha1[i]-d[i];
            if(cha1[i]<=0||cha2[i]<=0)
            {
                break;
            }
            cha2[i]=cha2[i]-c[i];
             if(cha1[i]<=0||cha2[i]<=0)
            {
                break;
            }
        }
    }
    for(i=0;i<t;i++)
    {
         if(cha1[i]<=0&&cha2[i]>0)
        {
            printf("Yes");
            if(i!=t-1)
            {
                printf("\n");
            }
        }
        else if(cha1[i]>0&&cha2[i]<=0)
        {
            printf("No");
            if(i!=t-1)
            {
                printf("\n");
            }
        }
    }
    return 0;
}
