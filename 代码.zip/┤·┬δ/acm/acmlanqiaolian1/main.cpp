#include <stdio.h>

int main()
{
    int i=0,n=1;
    double a[100],b[100],c[100]={0};
    while(n!=0)
    {
        scanf("%lf %lf",&a[i],&b[i]);
        c[i+1]=b[i]*a[i]+c[i];
        printf("%f\n",c[i+1]);
        i++;
    }
    return 0;
}
