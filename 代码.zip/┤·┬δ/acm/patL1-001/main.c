#include <stdio.h>
#include <stdlib.h>
#include <math.h>
int main()
{
    int i,n,h,j,m;
    char s;
    scanf("%d %c",&n,&s);
    if(n==1)
    {
        printf("%c\n",s);
        printf("0");
        return 0;
    }
    else
    {
        h=sqrt((n*1.0+1)/2);
        for(i=h;i>0;i--)
        {
            for(m=0;m<h-i;m++)
            {
                printf(" ");
            }
            for(j=0;j<(2*i-1);j++)
            {
                printf("%c",s);
            }
            for(m=0;m<h-i;m++)
            {
                printf(" ");
            }
             printf("\n");
        }
        for(i=2;i<=h;i++)
        {
            for(m=0;m<h-i;m++)
            {
                printf(" ");
            }
            for(j=0;j<(2*i-1);j++)
            {
                printf("%c",s);
            }
            for(m=0;m<h-i;m++)
            {
                printf(" ");
            }
             printf("\n");
        }
        printf("%d",n-2*h*h+1);
    }
    return 0;
}
