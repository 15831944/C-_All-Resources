#include <stdio.h>
int main()
{
     int n,i,t,a[10000],b,c,d,e,f,s;
     while(scanf("%d",&n)!=EOF)
     {
         if(n==0)
            return 0;
         s=0;
         for(i=1;i<=n;i++)
         {
             scanf("%d",&a[i]);
         }
         for(i=1;i<=n;i++)
         {
              t=0;
              b=0;
              c=0;
              d=0;
              e=0;
              f=0;
             t=a[i]/100;
             b=(a[i]-t*100)/50;
             c=(a[i]-t*100-b*50)/10;
             d=(a[i]-t*100-b*50-c*10)/5;
             e=(a[i]-t*100-b*50-c*10-d*5)/2;
             f=(a[i]-t*100-b*50-c*10-d*5-e*2)/1;
           s+=t+b+c+d+e+f;
           }

         printf("%d\n",s);
     }

    return 0;
}
