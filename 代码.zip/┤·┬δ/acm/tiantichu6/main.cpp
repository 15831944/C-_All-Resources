#include <stdio.h>

int main()
{
    int n,i,num_j=0,num_o=0,num1[1000];
    scanf("%d",&n);
    for(i=0;i<n;i++)
    {
        scanf("%d",&num1[i]);
    }
    for(i=0;i<n;i++)
    {
        if(num1[i]%2==0)
        {
            num_o++;
        }
        else if(num1[i]%2!=0)
        {
            num_j++;
        }
    }
    printf("%d %d",num_j,num_o);
    return 0;
}
