#include <stdio.h>
#include <string.h>

int main()
{
    char s[100];
    int i,n,len,sum,a[100],b=0;
     scanf("%d", &n);
     getchar();
     while(n--)
    {
        gets(s);
         sum=0;
        len=strlen(s);
          for(i=0;i<len;i++)
          {
              if(s[i]>='0'&&s[i]<='9')
              {
                sum++;
              }
          }
           a[b]=sum;
           b++;
    }
    for(i=0;i<b;i++)
    {
        printf("%d\n",a[i]);
    }
    return 0;
}

