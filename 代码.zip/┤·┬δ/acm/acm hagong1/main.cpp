# include <stdio.h>
int main()
{
    int t,n[100000],m[100000],k[100000],i;
    scanf("%d",&t);
    for(i=0;i<t;i++)
    {
       scanf("%d %d %d",&n[i],&m[i],&k[i]);
       if(m[i]!=0)
       {
           if(n[i]%m[i]+k[i]>=m[i]||n[i]%m[i]==0)
       {
           printf("Yes\n");
       }
       else
        printf("No\n");
       }
    }
    return 0;
}
