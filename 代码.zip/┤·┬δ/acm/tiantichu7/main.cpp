#include <stdio.h>
#include <stdlib.h>
#include <string.h>
int main()
{
    int i,len,num1=0,num2=0,num3=0,num4=0;
    char a[10000];
    gets(a);
    len=strlen(a);
    for(i=0;i<len;i++)
    {
        if(a[i]=='g'||a[i]=='G')
        {
            num1++;
        }
        else if(a[i]=='p'||a[i]=='P')
        {
            num2++;
        }
        else if(a[i]=='l'||a[i]=='L')
        {
            num3++;
        }
        else if(a[i]=='t'||a[i]=='T')
        {
            num4++;
        }
    }
    while(num1!=0||num2!=0||num3!=0||num4!=0)
    {
        if(num1>0)
        {
            printf("G");
            num1--;
        }
        if(num2>0)
        {
            printf("P");
            num2--;
        }
         if(num3>0)
        {
            printf("L");
            num3--;
        }
         if(num4>0)
        {
            printf("T");
            num4--;
        }
    }
    return 0;
}
