#include <stdio.h>
#include <stdlib.h>
#include <math.h>
int yue(int a,int b)
{
    int c,t;
    while(1)
    {
        c=a%b;
        if(c!=0)
        {
            t=b;
            b=c;
            a=t;
        }
        else
        {
            break;
        }
    }
    return b;
}
int main()
{
    int n,i,j,num=0,flag=0;
    long int m[100],z[100], m1,z1,mul=1,z2,z3=0,y;
    scanf("%d",&n);
    for(i=0;i<n;i++)
    {
        scanf("%ld/%ld",&z[i],&m[i]);
        mul*=m[i];
    }
    for(i=0;i<n;i++)
    {
        z2=z[i];
        for(j=0;j<n;j++)
        {
            if(i!=j)
            {
                z2*=m[j];
            }
        }
        z3+=z2;
    }
     m1=mul;
     z1=z3;
    if((z1<0&&m1>0)||(z1>0&&m1<0))
    {
        flag=1;
        z1=abs(z1);
        m1=abs(m1);
    }
    if(z1<0&&m1<0)
    {
         z1=abs(z1);
        m1=abs(m1);
    }
    num=z1/m1;
    z1=z1%m1;
    y=yue(z1,m1);
    if(num!=0)
    {
        printf("%d ",num);
        if(flag==1)
        {
            printf("-%ld/%ld",z1/y,m1/y);
        }
        else
        {
            printf("%ld/%ld",z1/y,m1/y);
        }
    }
    else
    {
        if(flag==1)
        {
            printf("-");
        }
        printf("%ld/%ld",z1/y,m1/y);
    }
    return 0;
}
