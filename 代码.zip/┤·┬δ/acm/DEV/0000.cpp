	# include<stdio.h>
	#include <string.h>
	int main()
	{
		char s[100];
		int len;
		int i;
		gets(s);
		len=strlen(s);
	    for(i=0;i<=len-1;i++){	
	     if((s[i]>='a'&&s[i]<='z')||(s[i]>='A'&&s[i]<='Z')){
	 	printf("%d",s[i]);
			}
	}
	}
