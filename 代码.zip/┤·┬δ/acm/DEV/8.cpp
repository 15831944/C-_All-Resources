	#include <stdio.h>
	int main()
	{
	int n;
	int i;
	int a;
	scanf ("%d",&n);
 	if(n==2)
	printf("yes");
	for(i=2;i<n;i++){
	 a=n%i;
	 if(a==0){
	 	printf("no");
	 	break;}
	} 
	if(a!=0){
		printf("yes");
	}

	return 0;
	}

