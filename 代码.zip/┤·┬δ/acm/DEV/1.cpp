#include <stdio.h>
int main()
{int a=1;
 int b=1;
  int c ;
 for(a=1;a<=9; a++)
{for(b=1;b<=a;b++)
{ c=a*b;
printf("%d\t",a*b);} 
printf("\n");}
} 
