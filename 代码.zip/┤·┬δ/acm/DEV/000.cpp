	# include<stdio.h>
	#include <string.h>
	int main()
	{
		char s[100];
		int len;
		int i;
		int a=0;
		int b=0;
		int c=0;
		gets(s);
		len=strlen(s);
	    for(i=0;i<=len-1;i++){
	    	if(s[i]>='0'&&s[i]<='9'){
	    		a++;	
			}else if((s[i]>='a'&&s[i]<='z')||(s[i]>='A'&&s[i]<='Z')){
				b++;	
			}else c++;
		}
		printf("%d\n%d\n%d\n",b,a,c);
	}
