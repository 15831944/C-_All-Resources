	# include <stdio.h>
	# include <string.h>
	int main()
	{
	int i;
	int len;
	char s[100];
	gets(s);
	len=strlen(s);
	i=len-1;
	for(;i>=0;i--){
	printf("%c",s[i]); 
	}
	return 0;
	}
