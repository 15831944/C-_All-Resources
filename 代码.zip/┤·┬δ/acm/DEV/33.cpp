	# include<stdio.h>
	int main()
	{
		int a;
		int b;
		long long c;
		int i;
		scanf("%d %d",&a,&b);
		c=a;
		for(i=2;i<=b;i++){
			c=c*a%1000000007;
		}
		printf("%lld",c);
		
	}
