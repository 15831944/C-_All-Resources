	# include <stdio.h>
	int main()
	{
		int m;
		int n;
		int a[3][3];
		int b;
		for(m=0;m<3;m++){
			for(n=0;n<3;n++){
				scanf("%d",&a[m][n]);
				}
		} 
		b=a[0][0]+a[1][1]+a[2][2];
		printf("%d",b);
	 } 
