#include <stdio.h>
	int main()
	{ int n;
	  int i;
	  int a[10];
	  int c;
	  int sum=0; 
	 scanf("%d",&n); 
	  for(i=0;i<n;i++){
	  	scanf("%d",&a[i]);
	  } 
	  for(i=0;i<n;i++){
	  	 c=a[i]%2;
	  	 if(c==0){
		  sum=sum+a[i]; 
		   }
  }
     printf("%d",sum);
}
