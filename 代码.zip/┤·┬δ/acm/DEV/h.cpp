# include <stdio.h>
int main()
{
	int a;
	int b;
	int c;
	int m=1000000007;
	scanf ("%d %d",&a,&b);
	c=a^b;
	printf("%d",a^b);
}
