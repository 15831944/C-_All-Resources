	# include <stdio.h>
	int main()
	{
		int a;
		int b[50];
		int c;
		int i=0;
		scanf("%d",&a);
		c=a;
	    do{
	    	b[i]=c%2;
	    	c=c/2;
	    	i++;
		}while(c!=0);
		for(;i>=1;i--) {
			printf("%d",b[i-1]);
		}
		}
