	# include <stdio.h>
	int main()
	{
	int i;
	int m[10];
	int n;
	scanf("%d",&n);
	if(n<=2){
		m[n-1]=1;
	}else
	{
	for(i=3;i<=n;i++){
	 m[0]=1;
	 m[1]=1;
	 m[i-1]=m[i-2]+m[i-3];
	}
	}
	printf("%d",m[n-1]);
	 } 
