	# include <stdio.h>
	int a(int n ){
		int i;
		int b;
		if(n<2)return 1;
		for(i=2;i*i<=n;i++){
		b=n%i;
		if(b==0){
			return 0;
		}	
		return 1;
		}
		
	}
	int main()
	{
		int M;
		int N;
		int count=-1;
		int c;
		scanf("%d %d",&M,&N);
	    for(c=M+1;c<N;c++){
	    	if(a(c)){
	    		count++;
	    		if(count%10==0){
	    			printf("\n");
				}
	    		printf("%3d",c);
			}
		}
		return 0;
	}
