	# include <stdio.h>
	int main()
	{
		int a;
		int b;
		int c;
		int i;
		scanf("%d %d %d",&a,&b,&c);
		if(a<=b){
			if(b<=c){
				printf("%d",c);
			}
			else{
				printf("%d",b);
			}
		}else{
			if(a<=c){
				printf("%d",c);
			}
		else
		printf("%d",a);
	}
}
