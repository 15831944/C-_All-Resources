#include<stdio.h>
int a(int n)
{
	int i,m;
	if(n<2) return 0;
	for(i=2;i*i<=n;i++)
	{
		
		m=n%i;
		if(m==0)
		{
			return 0;
		}	
	}
	return 1;
}
int main()
{
	int M,N;
	int count=-1;
	int j=0; 
	scanf("%d %d",&M,&N);
	for(j=M;j>=M&&j<N;j++)
	{
		if(a(j))
		{
		   count++;
		if(count % 10 == 0 && count != 0)  
		{
			printf("\n");
		}if (count % 10== 0)
		printf("%d",j);
		else
		printf(" %d",j);
		
		}
	}
	return 0;
}
