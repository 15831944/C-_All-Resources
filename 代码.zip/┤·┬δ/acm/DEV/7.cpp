	#include <stdio.h>
	int main()
	{
	int n;
	int i;
	int a;
	int sum;
	scanf("%d",&n);
	i=n+3;
	a=(1+3*n)*n;
	sum=a/2;
	printf("%d",sum);
	return 0;
	}
