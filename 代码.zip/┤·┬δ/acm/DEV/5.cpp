#include <stdio.h> 
int main()
{ int n;
  int i;
  int m=1;
  int sum=0;
  scanf("%d",&n);
  for(i=1;i<=n;i++) {
  	m=i*m;
  	sum=sum+m;
  }
  printf("%d",sum);
 } 
