#include <stdio.h>
#include <stdlib.h>

int main()
{
    int n,m,a[100],b[100],d[100],i,j=0,flag1=0,flag2=0,c,f,t;
    while(flag1==0)
    {
        scanf("%d",&n);
        scanf("%d",&m);
        if(n==0&&m==0)
        {
           return 0;
        }
        flag2=0;
        c=0;
        f=0;
        for(i=0; i<n; i++)
        {
           scanf("%d",&a[i]);
        }
        for(i=0;i<m;i++)
        {
            scanf("%d",&b[i]);
        }
        for(i=0;i<n;i++)
        {
            c=0;
            for(j=0;j<m;j++)
            {
                if(a[i]!=b[j])
                {
                    c++;
                }
            }
            if(c==m)
            {
                d[f]=a[i];
                f++;
                flag2=1;
            }
        }
        if(flag2==1)
        {
            for(i=0;i<f;i++)
            {
                for(j=0;j<f-i-1;j++)
                {
                    if(d[j]>d[j+1])
                    {
                        t=d[j];
                        d[j]=d[j+1];
                        d[j+1]=t;
                    }
                }
            }
            for(i=0;i<f;i++)
            {
                printf("%d ",d[i]);
            }
        }
        else
            printf("NULL");
        printf("\n");
    }
    return 0;
}
