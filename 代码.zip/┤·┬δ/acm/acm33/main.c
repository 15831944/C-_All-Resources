#include <stdio.h>
#include <stdlib.h>

int main()
{
    int n,i,a1[1000],a2[1000],a3[1000],A1[1000],A2[1000],A3[1000],b1[1000],b2[1000],b3[1000];
    scanf("%d",&n);
    for(i=0;i<n;i++)
    {
        scanf("%d %d %d %d %d %d",&a1[i],&a2[i],&a3[i],&b1[i],&b2[i],&b3[i]);
    }
    for(i=0;i<n;i++)
    {
        A3[i]=a3[i]+b3[i];
        A2[i]=a2[i]+b2[i];
        A1[i]=a1[i]+b1[i];
        if(A3[i]>=60)
        {
            A2[i]=A2[i]+1;
            A3[i]=A3[i]-60;
        }
        if(A2[i]>=60)
        {
            A1[i]=A1[i]+1;
            A2[i]=A2[i]-60;
        }
    }
    for(i=0;i<n;i++)
    {
        printf("%d %d %d\n",A1[i],A2[i],A3[i]);
    }
    return 0;
}
