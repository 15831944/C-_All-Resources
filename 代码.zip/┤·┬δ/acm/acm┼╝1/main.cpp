#include <stdio.h>
int main()
{
    int m,n,a,b,c,d=1,i,s;
    while(scanf("%d %d",&n,&m)!=EOF)
    {
        s=0;
        b=0;
        c=0;
        for(i=1; i<=n; i++)
        {
            a=2*i;
            if(b<m)
            {
                s+=a;
                b++;
            }
            if(b==m)
            {
                if(d==1)
            {
                printf("%d",s/m);
                d++;
            }
            else
                printf(" %d",s/m);
                s=0;
                b=0;
                c++;
            }
        }
        if(n-m*c!=0)
        {
            printf(" %d",s/(n-m*c));
        }
        printf("\n");
    }
    return 0;
}

