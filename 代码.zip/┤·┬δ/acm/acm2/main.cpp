#include <iostream>
#include<cstdio>
using namespace std;

int main()
{
    int a=0,b=0,c=0,i,n;
    double m[100];
   while( scanf("%d",&n)!=EOF)
            { a=0;
            b=0;
            c=0;
    if(n==0)
        {
            return 0;
        }
          for(i=0;i<n;i++)
            {
             scanf("%lf",&m[i]);
            }


           for(i=0;i<n;i++)
           {
               if(m[i]<0)
                a++;
               if(m[i]==0)
                b++;
               if(m[i]>0)
                c++;
           }

          printf("%d %d %d\n",a,b,c);
          }

    return 0;
}
