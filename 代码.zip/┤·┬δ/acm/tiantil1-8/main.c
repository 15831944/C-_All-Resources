#include <stdio.h>
#include <stdlib.h>

int main()
{
    int n,i,day_d[10],day_w[10],h_d[10],h_w[10],m_d[10],m_w[10],t;
    scanf("%d",&n);
    for(i=0; i<n; i++)
    {
        scanf("%d %d:%d",&day_d[i],&h_d[i],&m_d[i]);
    }
    for(i=0; i<n; i++)
    {
        if(day_d[i]==1)
        {
            day_w[i]=1;
            t=h_d[i]*60+m_d[i];
            h_w[i]=t/120;
            m_w[i]=(t-h_w[i]*120)/2;
        }
        else if(day_d[i]==2)
        {
            day_w[i]=1;
            t=h_d[i]*60+m_d[i];
            h_w[i]=t/120+12;
            m_w[i]=(t-(h_w[i]-12)*120)/2;
        }
        else if(day_d[i]==3||day_d[i]==4)
        {
            day_w[i]=2;
            if(day_d[i]==3)
            {
               t=h_d[i]*60+m_d[i];
            h_w[i]=t/120;
            m_w[i]=(t-h_w[i]*120)/2;
            }
            else
            {
                  t=h_d[i]*60+m_d[i];
            h_w[i]=t/120+12;
           m_w[i]=(t-(h_w[i]-12)*120)/2;
            }
        }
        else if(day_d[i]==5||day_d[i]==6)
        {
            day_w[i]=3;
            if(day_d[i]==5)
            {
                t=h_d[i]*60+m_d[i];
            h_w[i]=t/120;
            m_w[i]=(t-h_w[i]*120)/2;
            }
            else
            {
               t=h_d[i]*60+m_d[i];
            h_w[i]=t/120+12;
            m_w[i]=(t-(h_w[i]-12)*120)/2;
            }
        }
        else if(day_d[i]==0)
        {
            day_w[i]=0;
            h_w[i]=h_d[i];
            m_w[i]=m_d[i];
        }
    }
    for(i=0; i<n; i++)
    {
        printf("%d ",day_w[i]);
        if(h_w[i]<10)
        {
            printf("0");
        }
        printf("%d:",h_w[i]);
        if(m_w[i]<10)
        {
            printf("0");
        }
        printf("%d",m_w[i]);
        if(i!=n-1)
        {
            printf("\n");
        }
    }
    return 0;
}
