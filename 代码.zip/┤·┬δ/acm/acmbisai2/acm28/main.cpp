#include <stdio.h>
int gcd(int c ,int d)
{
    int y;
    if(d!=0)
        {
            y=c%d;
            c=d;
            d=y;
        }
        return c;
}
int main()
{
  int n,i,a[10000],c,d,y,b;
    while(scanf("%d",&n)!=EOF)
    {
        for(i=1; i<=n; i++)
        {
            scanf("%d",&a[i]);
        }
        for(i=2; i<=n; i++)
        {

           b=gcd(c=a[1],b=a[i]);
           a[1]=a[1]/c*a[i];
        }

        printf("%d\n",a[i]);
    }

        return 0;
    }

