#include <stdio.h>
#include<string.h>
int main()
{
    char a[100];
    int  i,len;
    while(gets(a))
    {
        len=strlen(a);
        a[0]=a[0]-32;
        for(i=0;i<len;i++)
        {
        if(a[i]==' ')
        {
            if(a[i+1]>='a'&&a[i+1]<='z')
            {
                a[i+1]=a[i+1]-32;
            }
        }
        }
        for(i=0;i<len;i++)
        {
            printf("%c",a[i]);
        }
        printf("\n");
    }

    return 0;
}
