#include<stdio.h>
#include<string.h>
int main()
{
    char a[100];
    int i,len;
    gets(a);
    len=strlen(a);
    a[0]=a[0]-32;
    for(i=0;i<len-1;i++)
    {
        if(a[i]==' ')
        {
            if(a[i+1]>='a'&&a[i+1]<='z')
            {
                a[i+1]=a[i+1]-32;
            }
        }
    }
    puts(a);
    return 0;
}
