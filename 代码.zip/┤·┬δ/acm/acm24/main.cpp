#include <stdio.h>
#include<string.h>

int main()
{
    int n,len,i,b;
    char a[100];
    scanf("%d",&n);
    getchar();
    while(n--)
    {
          b=0;
       gets(a);
       len=strlen(a);
           if(a[0]=='_'||(a[0]>='a'&&a[0]<='z')||(a[0]>='A'&&a[0]<='Z'))
           {
               for(i=1;i<len;i++)
               {
                   if(a[i]=='_'||(a[i]>='a'&&a[i]<='z')||(a[i]>='A'&&a[i]<='Z')||(a[i]>='0'&&a[i]<='9'))
                   {
                       b++;
                   }
               }
                   if(b==len-1)
                   {
                       printf("yes\n");
                   }
                   else
                   printf("no\n");

           }
           else
            printf("no\n");
    }

    return 0;
}
