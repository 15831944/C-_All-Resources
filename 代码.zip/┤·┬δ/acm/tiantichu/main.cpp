#include <stdio.h>
#include <stdlib.h>
int main()
{
    int h,m,i,n;
    scanf("%d:%d",&h,&m);
    if(h<=12)
    {
        if(h==12&&m==0)
        {
            printf("Only %d:%d0.  Too early to Dang.",h,m);
            return 0;
        }
        else if(h==12&&m>0)
        {
            printf("Dang");
            return 0;
        }
        else if(h<12)
        {
            if(h>=10&&m>=10)
            {
                printf("Only %d:%d.  Too early to Dang.",h,m);
                return 0;
            }
            else if(h>=10&&m<10)
            {
                 printf("Only %d:0%d.  Too early to Dang.",h,m);
                 return 0;
            }
            else if(h<10&&m<10)
            {
                  printf("Only 0%d:0%d.  Too early to Dang.",h,m);
                  return 0;
            }
            else if(h<10&&m>10)
            {
               printf("Only 0%d:%d.  Too early to Dang.",h,m);
               return 0;
            }
        }
    }
    else
    {
        n=h-12;
        if(m>0)
            n++;
        for(i=1;i<=n;i++)
        {
            printf("Dang");
        }
    }
    return 0;
}
