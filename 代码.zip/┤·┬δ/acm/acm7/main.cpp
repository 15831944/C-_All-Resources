#include <stdio.h>

int main()
{
    int N,Li[10000],Ri[10000],i,h=0;
    scanf("%d",&N);
    for(i=0; i<N; i++)
    {   h=0;
        scanf("%d %d",&Li[i],&Ri[i]);
    }
    for(i=0; i<N; i++)
    {
        h+=Ri[i]-Li[i]+1;
    }

  printf("%d\n",h);
    return 0;
}
