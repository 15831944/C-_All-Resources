#include <stdio.h>
int main ()
{
    int i;
    for(i=0;i<3;i++)
    {
        if(i!=2)
        {
            printf("I'm gonna WIN!\n");
        }
        else
        {
            printf("I'm gonna WIN!");
        }
    }
    return 0;
}
