#include <stdio.h>

int main()
{
    int min,n,i,s[10000],t,a;
    while(scanf("%d",&n)!=EOF)
    {     t=1;
        if(n==0)
            return 0;
        for(i=1;i<=n;i++)
        {
            scanf("%d",&s[i]);
        }
         min=s[1];
        for(i=1;i<n;i++)
        {
            if(min>s[i+1])
            {
                min=s[i+1];
                t=i+1;
            }
        }
        a=s[1];
        s[1]=min;
        s[t]=a;
        for(i=1;i<=n;i++)
        {   if(i==1)
            printf("%d",s[i]);
            else
                printf(" %d",s[i]);
        }
        printf("\n");
    }
    return 0;
}

