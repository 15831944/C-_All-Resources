#include <stdio.h>
#include <stdlib.h>
#include <string.h>
int main()
{
    char num[1100];
    int i,len,num_[11]= {0};
    gets(num);
    len=strlen(num);
    for(i=0; i<len; i++)
    {
        if(num[i]=='0')
           {
               num_[0]++;
           }
            else if(num[i]=='1')
            {
                num_[1]++;
            }
            else if(num[i]=='2')
            {
                num_[2]++;
            }
            else if(num[i]=='3')
            {
                num_[3]++;
            }
            else if(num[i]=='4')
            {
                num_[4]++;
            }
            else if(num[i]=='5')
            {
                num_[5]++;
            }
            else if(num[i]=='6')
            {
                num_[6]++;
            }
            else if(num[i]=='7')
            {
                num_[7]++;
            }
            else if(num[i]=='8')
            {
                num_[8]++;
            }
            else if(num[i]=='9')
            {
                num_[9]++;
            }
    }
    for(i=0; i<10; i++)
    {
        if(num_[i]!=0)
        {
            printf("%d:%d\n",i,num_[i]);
        }
    }
    return 0;
}
