#include <stdio.h>
#include<math.h>
#include <stdlib.h>
int main()
{
    int n,i,a,s[1000],b[1000],t;
    while(scanf("%d",&n)!=EOF)
    {
        if(n==0)
            return 0;
        for(i=1;i<=n;i++)
        {
            scanf("%d",&s[i]);
        }
        for(i=1;i<=n;i++)
        {
            for(a=1;a<=n-i;a++)
            {
                if(abs(s[a])<abs(s[a+1]))
                {
                    t=s[a];
                    s[a]=s[a+1];
                    s[a+1]=t;
                }
            }
        }

        for(i=1;i<=n;i++)
        {
            if(i==1)
            printf("%d",s[i]);
            else
            {
                printf(" %d",s[i]);
            }
        }
        printf("\n");
    }
    return 0;
}
