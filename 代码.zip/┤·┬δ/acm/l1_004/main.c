#include <stdio.h>
#include <stdlib.h>

int main()
{
    int f,c;
    scanf("%d",&f);
    c=5*(f-32)/9;
    printf("Celsius = %d\n",c);
    return 0;
}
