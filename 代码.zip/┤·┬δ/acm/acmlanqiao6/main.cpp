#include <stdio.h>
#include <stdlib.h>
#include <math.h>
int main()
{
    int n,m,t=1,i,b,j,j1=1,a1=1,m1=1;
    int sum=0;
    scanf("%d",&t);
    while(t--)
    {
       scanf("%d %d",&n,&m);
        j1=1;
        a1=1;
        m1=1;
        for(i=1; i<=m; i++)
        {
            m1*=i;
        }
        if(n<=m)
        {
            for(i=1; i<=n; i++)
            {
                for(j=1; j<=i; j++)
                {
                    j1*=i;
                }
                b=abs(m-i);
                for(j=1; j<=b; j++)
                {
                    a1*=j;
                }

                sum+=(m1/(j1*a1))%1000000007;
            }
        }
            else
            {
                for(i=1; i<=m; i++)
                {
                    for(j=1; j<=i; j++)
                    {
                        j1*=i;
                    }
                    b=abs(m-i);
                    for(j=1; j<=b; j++)
                    {
                        a1*=j;
                    }

                    sum+=(m1/(j1*a1))%1000000007;
                }
            }
            printf("%d\n",sum);
        }
        return 0;
    }
