#include <stdio.h>

int main()
{
    int n,a,b,c,x,y,flag=0;
    while(scanf("%d %d",&x,&y)!=EOF)
    {  flag=0;
    if(x==0&&y==0)
    {
       break;
    }
    else
        {
    for(n=x;n<=y;n++)
        {
              a=n*n+n+41;
              for(b=2;b<a;b++)
              {
                  c=a%b;
                  if(c==0)
                  {
                      flag=1;
                  }
              }
        }
        if(flag==1)
        {
            printf("Sorry\n");
        }
        if(flag==0)
            printf("OK\n");
    }
    }

    return 0;
}
