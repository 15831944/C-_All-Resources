#include <stdio.h>
int main()
{
    int i,j, m,n,s[1000],t;
    while(scanf("%d %d",&n,&m)!=EOF)
        {
    if(n==0&&m==0)
        return 0;
    for(i=1;i<=n;i++)
    {
        scanf("%d",&s[i]);
    }
    s[n+1]=m;
    for(i=1;i<=n+1;i++)
    {
       for(j=1;j<=n+1-i;j++)
       {
           if(s[j]>s[j+1])
           {
               t=s[j];
               s[j]=s[j+1];
               s[j+1]=t;
           }
       }
    }
    for(i=1;i<=n+1;i++)
    {
        if(i==1)
        printf("%d",s[i]);
        else
        printf(" %d",s[i]);
    }
    printf("\n");
    }
    return 0;
}
