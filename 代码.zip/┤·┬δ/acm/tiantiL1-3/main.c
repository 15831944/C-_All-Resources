#include <stdio.h>
#include <stdlib.h>
#include <string.h>
int main()
{
    int n[21],num1[21]= {0},num2[21]= {0},i,len,len1,len2,j,num[21]= {0},m=0,flag=0;
    char n1[21],num_1[21],num_2[21];
    gets(n1);
    len=strlen(n1);
    for(i=0; i<len; i++)
    {
        n[i]=n1[i]-'0';
    }
    gets(num_1);
    len1=strlen(num_1);
    for(i=0; i<len1; i++)
    {
        num1[i]=num_1[i]-'0';
    }
    gets(num_2);
    len2=strlen(num_2);
    for(i=0; i<len2; i++)
    {
        num2[i]=num_2[i]-'0';
    }
    for(i=len1-1; i>=0; i--)
    {
        j=len2-1-m;
        if(j<0)
        {
            num[20-m]=num1[i]+flag;
        }
        else
        {
            num[20-m]=num1[i]+num2[j]+flag;
        }
        flag=0;
        if(n[len-1-m]==0)
        {
            n[len-1-m]=10;
        }
        while(num[20-m]>=n[len-1-m])
        {
            num[20-m]=num[20-m]-n[len-1-m];
            flag++;
        }
        m++;
    }
    for(j=0; j<21; j++)
    {
        if(num[j]!=0)
        {
            i=j;
            break;
        }
    }
    for(; i<21; i++)
    {
        printf("%d",num[i]);
    }
    return 0;
}
