#include <stdio.h>

int main()
{
    int m[1000],n,x,i,a,b,c;
    for(i=1;i<=12;i++)
    {
        scanf("%d",&m[i]);
    }
    a=0;
    b=0;
    for(i=1;i<=12;i++)
    {
       c=1000+b;
       n=(c-m[i])/100;
       b=c-m[i]-n*100;
       a+=n*100;
       if(c-m[i]<0)
       {
           printf("-%d",i);
           return 0;
       }

    }
    x=a*1.2+b;
    printf("%d",x);
    return 0;
}
