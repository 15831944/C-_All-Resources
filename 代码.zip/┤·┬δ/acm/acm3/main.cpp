#include <stdio.h>
#include <math.h>
int main()
{
    int a,b,c,d,i,m,n,e,flag=0;

    while(scanf("%d %d",&m,&n)!=EOF)
    {    e=0;
        for(i=m; i<=n; i++)
        {
            a=i/100;
            b=i/10%10;
            c=i%10;
            d=pow(a,3)+pow(b,3)+pow(c,3);
            if(i==d&&e==0)
            {
                printf("%d",i);
                flag=1;
                e++;
            }
           else if(i==d)
                {
                printf(" %d",i);
                flag=1;
                }
        }
        if(flag==0)
            printf("no");

        printf("\n");

    }

    return 0;
}
